// ПОДХОД · парсер нотации блокнота (FR-17, §2 — закон совместимости)
// «Тяга верхнего блока 52 кг на 9» / «39 кг на 11 2» / «61 кг на 6 + 45 кг на 4»
// «4,5 кг 12» / «52×9×2» / «Свой вес на 12». Хвостовое число = количество подходов.
import { normName, round2 } from './util.js';

const SET_START = /(\d+(?:[.,]\d+)?)\s*(?:кг|на\s*\d|[×xхХ*]\s*\d)|свой\s*вес|(?:^|\s)св(?:\s|$)/i;
const HEADER = /^тренировка\s*№?\s*(\d+)\b\s*(.*)$/i;
const DATE_LINE = /^(?:дата[:\s]+)?(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?$/i;

const RE_BODY = /^(?:свой\s*вес|св)\s*(?:на\s*)?(\d+)(?:\s*[×x*]?\s*(\d+))?$/i;
// A: «39 кг на 11 2», «4,5 кг 12», «52 кг 9 ×2»
const RE_KG = /^(\d+(?:[.,]\d+)?)\s*кг\s*(?:на\s*)?(\d+)(?:\s*[×x*]?\s*(\d+))?$/i;
// B: «52 на 9», «52×9×2», «52 на 9 2»
const RE_MARK = /^(\d+(?:[.,]\d+)?)\s*(?:на|[×x*])\s*(\d+)(?:\s*[×x*]?\s*(\d+))?$/i;

const num = s => round2(parseFloat(String(s).replace(',', '.')));

export function resolveExercise(nameRaw, catalog) {
  const n = normName(nameRaw);
  if (!n) return null;
  for (const e of catalog) {
    if (normName(e.name) === n) return e;
    if ((e.aliases || []).some(a => normName(a) === n)) return e;
  }
  return null;
}

function parseSegment(seg, lineNo, issues) {
  const s = seg.trim().replace(/[хХ]/g, 'x');
  if (!s) return null;
  let m, w, r, c;
  if ((m = s.match(RE_BODY))) { w = 0; r = +m[1]; c = m[2] ? +m[2] : 1; }
  else if ((m = s.match(RE_KG)) || (m = s.match(RE_MARK))) {
    w = num(m[1]); r = +m[2]; c = m[3] ? +m[3] : 1;
  } else {
    issues.push({ line: lineNo, kind: 'bad-set', text: seg.trim(), message: 'Не распознан подход' });
    return null;
  }
  if (!(w >= 0 && w <= 500) || !(r >= 1 && r <= 100) || !(c >= 1 && c <= 50)) {
    issues.push({ line: lineNo, kind: 'bad-set', text: seg.trim(), message: 'Значения вне диапазона (вес 0–500, повторы 1–100, подходы 1–50)' });
    return null;
  }
  return { weightKg: w, reps: r, count: c };
}

function parseDateToken(tok, fallbackYear) {
  const m = tok.trim().match(DATE_LINE);
  if (!m) return null;
  let [, d, mo, y] = m;
  d = +d; mo = +mo;
  if (d < 1 || d > 31 || mo < 1 || mo > 12) return null;
  y = y ? +y : fallbackYear;
  if (y < 100) y += 2000;
  const p = n => String(n).padStart(2, '0');
  return `${y}-${p(mo)}-${p(d)}`;
}

// Главный вход: текст + каталог → блоки тренировок с предпросмотром и ошибками.
export function parseNotebook(text, catalog, { year = new Date().getFullYear() } = {}) {
  const blocks = [];
  let block = null;
  const newBlock = num => {
    block = { num, date: null, entries: [], issues: [] };
    blocks.push(block);
    return block;
  };
  const lines = String(text ?? '').split(/\r?\n/);

  lines.forEach((raw, i) => {
    const lineNo = i + 1;
    const line = raw.trim();
    if (!line) return;

    const h = line.match(HEADER);
    if (h) {
      newBlock(+h[1]);
      const rest = h[2].trim();
      if (rest) {
        const d = parseDateToken(rest.replace(/[()]/g, ''), year);
        if (d) block.date = d;
        else block.issues.push({ line: lineNo, kind: 'note', text: rest, message: 'Текст после номера сохранён в заметку' });
        if (!d) block.headerNote = rest;
      }
      return;
    }
    if (!block) newBlock(null);

    const d = parseDateToken(line, year);
    if (d) { block.date = d; return; }

    const idx = line.search(SET_START);
    const namePart = idx >= 0 ? line.slice(0, idx).trim() : line;
    const setsPart = idx >= 0 ? line.slice(idx) : '';

    // Сначала пробуем разобрать подходы; если ни один не вышел — строка целиком ошибка
    let parsed = [];
    if (setsPart) {
      const tmpIssues = [];
      for (const seg of setsPart.split('+')) {
        const g = parseSegment(seg, lineNo, tmpIssues);
        if (g) parsed.push(g);
      }
      if (!parsed.length) {
        block.issues.push({ line: lineNo, kind: 'bad-line', text: line, message: 'Строка не распознана' });
        return;
      }
      block.issues.push(...tmpIssues);
    }

    let entry = null;
    if (namePart) {
      const found = resolveExercise(namePart, catalog);
      entry = {
        nameRaw: namePart,
        exerciseId: found?.id ?? null,
        name: found?.name ?? namePart,
        group: found?.group ?? null,
        isNew: !found,
        sets: [],
      };
      block.entries.push(entry);
      if (!found) block.issues.push({ line: lineNo, kind: 'new-exercise', text: namePart, message: 'Нет в каталоге — будет создано' });
    } else {
      entry = block.entries[block.entries.length - 1] ?? null;
      if (!entry) {
        block.issues.push({ line: lineNo, kind: 'orphan', text: line, message: 'Подходы без упражнения — укажите название выше' });
        return;
      }
    }
    entry.sets.push(...parsed);
  });

  // Пустые блоки (заголовок без содержимого) оставляем — импорт покажет их как пустые
  return { blocks };
}

// Автоопределение сплита по большинству мышечных групп упражнений
export function guessSplit(entries, catalog) {
  const byId = new Map(catalog.map(e => [e.id, e.group]));
  const count = { 'Грудь': 0, 'Спина': 0, 'Ноги': 0 };
  for (const en of entries) {
    const g = en.group ?? byId.get(en.exerciseId);
    if (g in count) count[g] += Math.max(1, en.sets.length);
  }
  const best = Object.entries(count).sort((a, b) => b[1] - a[1])[0];
  if (!best || best[1] === 0) return null;
  return { 'Грудь': 'chest', 'Спина': 'back', 'Ноги': 'legs' }[best[0]];
}
