// ПОДХОД · импорт из текстовых заметок (FR-17): предпросмотр, ошибки со строками, ничего не теряется
import { state, importNotebookBlock, notify } from '../core/store.js';
import { todayISO, escapeHtml, fmtDate } from '../core/util.js';
import { parseNotebook, guessSplit } from '../core/parser.js';
import { splitForDate, nextNum, SPLITS, SPLIT_KEYS } from '../core/scheduler.js';
import { GROUPS } from '../core/seed.js';
import { setNotation } from '../core/format.js';
import { navigate } from './router.js';
import { icon, setChip, empty } from './components.js';

const SAMPLE = `Тренировка 36
Тяга верхнего блока 52 кг на 9
39 кг на 11 2
61 кг на 6 + 45 кг на 4
На скамье пулловер 16 кг на 12
Блок бицепс 25 кг на 12 2
4,5 кг 15`;

let text = '';
let blocks = null;
let opts = [];
let timer = null;

function reparse() {
  if (!text.trim()) { blocks = null; opts = []; renderPreview(); return; }
  const res = parseNotebook(text, state.exercises);
  blocks = res.blocks;
  let auto = nextNum(state.workouts);
  opts = blocks.map((b, i) => {
    const prev = opts[i];
    const date = prev?.date ?? b.date ?? todayISO();
    return {
      num: prev?.num ?? b.num ?? auto++,
      date,
      split: prev?.split ?? guessSplit(b.entries, state.exercises) ?? splitForDate(date, state.settings.schedule) ?? 'chest',
      replace: prev?.replace ?? false,
      newGroups: prev?.newGroups ?? {},
    };
  });
  renderPreview();
}

const conflict = i => state.workouts.some(w => w.num === opts[i]?.num);

function previewHTML() {
  if (!blocks) return empty('📋', 'Вставьте заметку из блокнота', 'Понимаю: «52 кг на 9», хвостовое число = подходы, цепочки «+», «4,5 кг 12», «60×8×3», свой вес');
  if (!blocks.length) return empty('🤔', 'Пусто', 'Не нашёл ни одной строки');
  return blocks.map((b, i) => {
    const o = opts[i];
    const setsTotal = b.entries.reduce((t, e) => t + e.sets.reduce((a, s) => a + s.count, 0), 0);
    const hardIssues = b.issues.filter(x => ['bad-line', 'bad-set', 'orphan'].includes(x.kind));
    return `
    <div class="card">
      <div class="card-head" style="flex-wrap:wrap">
        <h3>Тренировка</h3>
        <input type="number" inputmode="numeric" value="${o.num}" data-change="opt-num" data-b="${i}" style="width:84px;min-height:44px" aria-label="Номер">
        <input type="date" value="${o.date}" data-change="opt-date" data-b="${i}" style="width:150px;min-height:44px" aria-label="Дата">
        <select data-change="opt-split" data-b="${i}" style="width:110px;min-height:44px" aria-label="Сплит">
          ${SPLIT_KEYS.map(k => `<option value="${k}" ${o.split === k ? 'selected' : ''}>${SPLITS[k].label}</option>`).join('')}
        </select>
      </div>
      ${conflict(i) ? `
      <div class="issue err"><span class="ln">№${o.num}</span><span>Такой номер уже есть в истории.</span></div>
      <label class="toggle-row" style="cursor:pointer"><div class="grow"><div class="t-label">Заменить существующую</div><div class="t-sub">иначе блок будет пропущен</div></div>
        <input type="checkbox" ${o.replace ? 'checked' : ''} data-change="opt-replace" data-b="${i}" style="width:24px;min-height:24px"></label>` : ''}
      ${b.entries.map((e, ei) => `
        <div class="exercise-block">
          <div class="ex-name">${escapeHtml(e.name)}
            ${e.isNew ? `<select data-change="opt-group" data-b="${i}" data-e="${ei}" style="width:110px;min-height:36px;padding:4px 8px;font-size:.8rem" aria-label="Группа нового упражнения">
              ${GROUPS.map(g => `<option ${ (o.newGroups[ei] ?? 'Грудь') === g ? 'selected' : ''}>${g}</option>`).join('')}
            </select><span class="group-tag" style="color:var(--legs);border-color:var(--legs)">новое</span>` : `<span class="group-tag">${e.group}</span>`}
          </div>
          <div class="set-row">${e.sets.map(s => setChip(s, { stat: true })).join('') || '<span class="muted small">без подходов</span>'}</div>
        </div>`).join('')}
      ${b.issues.map(x => `
        <div class="issue ${x.kind === 'new-exercise' ? 'warn' : x.kind === 'note' ? 'info' : 'err'}">
          <span class="ln">стр. ${x.line}</span><span>${escapeHtml(x.message)}: <span class="mono">${escapeHtml(x.text)}</span></span>
        </div>`).join('')}
      ${hardIssues.length ? `<p class="muted tiny">Нераспознанные строки сохранятся в заметку тренировки — ничего не потеряется.</p>` : ''}
      <div class="stat-line"><span><b>${b.entries.length}</b> упр.</span><span><b>${setsTotal}</b> подх.</span><span>${fmtDate(o.date)}</span></div>
    </div>`;
  }).join('');
}

function renderPreview() {
  const el = document.getElementById('import-preview');
  if (el) el.innerHTML = previewHTML();
  const btn = document.getElementById('import-btn');
  if (btn) {
    const total = blocks?.reduce((t, b) => t + b.entries.reduce((a, e) => a + e.sets.length, 0), 0) ?? 0;
    btn.disabled = !total;
    btn.innerHTML = `${icon('upload')} Импортировать (${blocks?.length ?? 0})`;
  }
}

export function render() {
  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="nav" data-to="more" aria-label="Назад">${icon('chevL')}</button>
    <h1>Импорт заметок</h1>
  </div>
  <div class="card">
    <textarea id="import-text" data-input="text" rows="8" class="mono" placeholder="Тренировка 36&#10;Тяга верхнего блока 52 кг на 9&#10;39 кг на 11 2&#10;61 кг на 6 + 45 кг на 4" style="font-size:.88rem">${escapeHtml(text)}</textarea>
    <div class="btn-row" style="margin-top:10px">
      <button class="btn small-btn" data-action="sample">${icon('note')} Вставить пример</button>
      <button class="btn small-btn ghost" data-action="clear">Очистить</button>
    </div>
  </div>
  <div id="import-preview">${previewHTML()}</div>
  <button class="btn primary big" id="import-btn" data-action="do-import" disabled>${icon('upload')} Импортировать (0)</button>
  <p class="muted tiny" style="margin-top:10px">Закон блокнота: хвостовое число — количество одинаковых подходов; строки с весами без названия относятся к последнему упражнению. Дубликаты номеров пропускаются, если не включена замена.</p>`;
}

export const actions = {
  sample: () => { text = SAMPLE; reparse(); const ta = document.getElementById('import-text'); if (ta) ta.value = text; },
  clear: () => { text = ''; blocks = null; opts = []; const ta = document.getElementById('import-text'); if (ta) ta.value = ''; renderPreview(); },
  'opt-num': el => { opts[+el.dataset.b].num = Math.max(1, parseInt(el.value, 10) || 1); renderPreview(); },
  'opt-date': el => { opts[+el.dataset.b].date = el.value || todayISO(); renderPreview(); },
  'opt-split': el => { opts[+el.dataset.b].split = el.value; },
  'opt-replace': el => { opts[+el.dataset.b].replace = el.checked; },
  'opt-group': el => { opts[+el.dataset.b].newGroups[+el.dataset.e] = el.value; },
  'do-import': async () => {
    if (!blocks?.length) return;
    let imported = 0, skipped = 0;
    for (let i = 0; i < blocks.length; i++) {
      const b = blocks[i], o = opts[i];
      const lost = b.issues.filter(x => ['bad-line', 'bad-set', 'orphan'].includes(x.kind)).map(x => `стр. ${x.line}: ${x.text}`);
      const note = [b.headerNote, lost.length ? 'Нераспознанные строки:\n' + lost.join('\n') : ''].filter(Boolean).join('\n');
      const entries = b.entries.map((e, ei) => ({
        name: e.name, exerciseId: e.exerciseId,
        group: e.isNew ? (o.newGroups[ei] ?? 'Грудь') : e.group,
        sets: e.sets,
      }));
      const res = await importNotebookBlock({ num: o.num, date: o.date, split: o.split, entries, note }, { replace: o.replace });
      if (res.skipped) skipped++; else imported++;
    }
    text = ''; blocks = null; opts = [];
    navigate('history');
    setTimeout(() => alert(`Импортировано тренировок: ${imported}${skipped ? `\nПропущено дубликатов: ${skipped}` : ''}`), 350);
  },
};

export const inputs = {
  text: el => {
    text = el.value;
    clearTimeout(timer);
    timer = setTimeout(reparse, 400);
  },
};
