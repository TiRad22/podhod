// ПОДХОД · UI-kit: иконки, чипы, степперы, графики (inline SVG, без зависимостей)
import { fmtKg, fmtInt, escapeHtml } from '../core/util.js';

const P = {
  home: 'M3 10.5 12 3l9 7.5M5 9.5V21h5v-6h4v6h5V9.5',
  history: 'M12 8v4l3 2M3.05 11a9 9 0 1 1 .5 4M3 4v5h5',
  chart: 'M4 20V10M10 20V4M16 20v-7M21 20H3',
  dots: 'M5 12h.01M12 12h.01M19 12h.01',
  plus: 'M12 5v14M5 12h14',
  minus: 'M5 12h14',
  up: 'M12 19V5M5 12l7-7 7 7',
  down: 'M12 5v14M19 12l-7 7-7-7',
  trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6',
  edit: 'M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z',
  copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
  check: 'M20 6 9 17l-5-5',
  x: 'M18 6 6 18M6 6l12 12',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM21 21l-4.3-4.3',
  timer: 'M12 22a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM12 10v4l2.5 2.5M9 2h6',
  play: 'M6 4l14 8-14 8Z',
  flag: 'M4 22V4c4-2 8 2 12 0v10c-4 2-8-2-12 0',
  moon: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z',
  sun: 'M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10ZM12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  upload: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  scale: 'M12 3v3M6 21h12M12 6a7 7 0 0 1 7 7c0 2-1 4-2 5H7c-1-1-2-3-2-5a7 7 0 0 1 7-7ZM12 13l2.5-2.5',
  bed: 'M2 4v16M2 8h18a2 2 0 0 1 2 2v10M2 17h20M6 8v9M2 12h4',
  book: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 19.5A2.5 2.5 0 0 0 6.5 22H20V2H6.5A2.5 2.5 0 0 0 4 4.5Z',
  zap: 'M13 2 3 14h9l-1 8 10-12h-9l1-8Z',
  chevR: 'M9 18l6-6-6-6',
  chevL: 'M15 18l-6-6 6-6',
  trophy: 'M8 21h8M12 17v4M7 4h10v6a5 5 0 0 1-10 0ZM7 6H4a2 2 0 0 0 2 4h1M17 6h3a2 2 0 0 1-2 4h-1',
  dumbbell: 'M6.5 6.5v11M17.5 6.5v11M3 9v6M21 9v6M6.5 12h11',
  note: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8ZM14 2v6h6M16 13H8M16 17H8M10 9H8',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z',
  repeat: 'M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3',
  plate: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z',
};
export const icon = (name, cls = '') =>
  `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[name] ?? P.plate}"/></svg>`;

export const plateNum = (num, split, big = false) =>
  `<span class="plate-num ${split}${big ? ' big' : ''}">${num}</span>`;

export const splitTag = split =>
  `<span class="split-tag ${split}">${{ chest: 'Грудь', back: 'Спина', legs: 'Ноги' }[split] ?? split}</span>`;

// Чип подхода в нотации блокнота: «52×9», «39×11 ·2», свой вес = «СВ»
export function setChip(g, { ghost = false, stat = false, action = '', attrs = '' } = {}) {
  const w = g.weightKg > 0 ? fmtKg(g.weightKg) : 'СВ';
  const pr = g.pr ? '<span class="pr-star">★</span>' : '';
  const cnt = g.count > 1 ? `<span class="cnt">·${g.count}</span>` : '';
  const rpe = g.rpe ? `<span class="rpe">@${g.rpe}${g.failure ? '!' : ''}</span>` : '';
  const cls = `set-chip${ghost ? ' ghost' : ''}${g.pr ? ' pr' : ''}${stat ? ' static' : ''}`;
  const act = stat ? '' : `data-action="${action}" ${attrs}`;
  return `<button class="${cls}" ${act} ${stat ? '' : `aria-label="${ghost ? 'Повторить' : 'Изменить'} подход ${w} на ${g.reps}${g.count > 1 ? `, ${g.count} шт` : ''}"`}>${w}×${g.reps}${cnt}${rpe}${pr}</button>`;
}

export function stepper({ key, label, value, unit = '', step = 1, min = 0, max = 999, hint = '', fine = false, changeOnly = false }) {
  const valAttr = changeOnly ? 'data-change="stepval"' : 'data-input="stepval"';
  return `
  <div class="field-label"><span>${label}</span>${hint ? `<span class="muted">${hint}</span>` : ''}</div>
  <div class="stepper">
    <button class="step-btn" data-action="step" data-key="${key}" data-delta="-${step}" aria-label="Уменьшить ${label}">−</button>
    <div class="step-val">
      <input inputmode="decimal" ${valAttr} data-key="${key}" data-min="${min}" data-max="${max}" value="${String(value).replace('.', ',')}" aria-label="${label}">
      <span class="step-unit">${unit}</span>
    </div>
    <button class="step-btn" data-action="step" data-key="${key}" data-delta="${step}" aria-label="Увеличить ${label}">+</button>
  </div>
  ${fine ? `<div class="fine-row">
    <button class="fine-btn" data-action="step" data-key="${key}" data-delta="-0.5">−0,5</button>
    <button class="fine-btn" data-action="step" data-key="${key}" data-delta="0.5">+0,5</button>
    <button class="fine-btn" data-action="setval" data-key="${key}" data-value="0">Свой вес</button>
  </div>` : ''}`;
}

export const scaleRow = (action, values, active, labels = null) =>
  `<div class="scale-row">${values.map(v =>
    `<button class="scale-btn${active === v ? ' active' : ''}" data-action="${action}" data-value="${v}">${labels ? labels[v] ?? v : v}</button>`).join('')}</div>`;

export const toggleRow = (label, sub, checked, action, attrs = '') =>
  `<div class="toggle-row"><div class="grow"><div class="t-label">${label}</div>${sub ? `<div class="t-sub">${sub}</div>` : ''}</div>
   <button class="switch" role="switch" aria-checked="${checked}" data-action="${action}" ${attrs} aria-label="${label}"></button></div>`;

export const empty = (emoji, title, sub = '') =>
  `<div class="empty"><div class="empty-icon">${emoji}</div><p><b>${title}</b></p>${sub ? `<p class="small">${sub}</p>` : ''}</div>`;

/* ── Модальные окна / шторки ── */
let modal = null;
export function openModal({ html, actions = {}, inputs = {}, sheet = true, onClose = null }) {
  modal = { actions, inputs, onClose };
  const root = document.getElementById('modal-root');
  root.innerHTML = `<div class="modal-scrim" data-action="modal-close"></div>
    <div class="${sheet ? 'sheet' : 'modal'}" role="dialog" aria-modal="true">${sheet ? '<div class="sheet-handle"></div>' : ''}${html}</div>`;
  return root;
}
export function closeModal() {
  const m = modal; modal = null;
  document.getElementById('modal-root').innerHTML = '';
  m?.onClose?.();
}
export const modalActions = () => modal?.actions ?? null;
export const modalInputs = () => modal?.inputs ?? null;
export const isModalOpen = () => !!modal;
export function setModalBody(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

/* ── PR-празднование: ≤ 1 с, не блокирует ввод ── */
export function celebrate(oneRm) {
  const old = document.getElementById('pr-pop');
  old?.remove();
  const pop = document.createElement('div');
  pop.id = 'pr-pop';
  pop.innerHTML = oneRm > 0
    ? `${icon('trophy')} PR! 1ПМ ≈ ${fmtKg(Math.round(oneRm * 10) / 10)} кг`
    : `${icon('trophy')} Новый рекорд!`;
  document.body.appendChild(pop);
  setTimeout(() => pop.remove(), 1000);
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const colors = ['#E5484D', '#4D82FF', '#F5B301', '#3FB950', '#F2EFE6'];
  for (let i = 0; i < 14; i++) {
    const c = document.createElement('div');
    c.className = 'confetti';
    c.style.background = colors[i % colors.length];
    c.style.setProperty('--cx', `${(Math.random() - 0.5) * 260}px`);
    c.style.setProperty('--cy', `${60 + Math.random() * 160}px`);
    c.style.setProperty('--cr', `${(Math.random() - 0.5) * 720}deg`);
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 950);
  }
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { /* noop */ }
    ta.remove(); return ok;
  }
}

/* ── Графики: чистый SVG, значения подписаны, тапы ≥ 48 px через хит-зоны ── */
const esc = escapeHtml;
const compactTon = v => v >= 1000 ? `${(v / 1000).toFixed(1).replace('.', ',')}т` : String(Math.round(v));

export function lineChart(series, { color = 'var(--primary)', unit = 'кг', height = 190 } = {}) {
  if (!series.length) return empty('📈', 'Пока нет данных', 'Завершите хотя бы одну тренировку с этим упражнением');
  const W = 360, H = height, padL = 34, padR = 14, padT = 22, padB = 26;
  const vals = series.map(s => s.value);
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (hi - lo < 1e-6) { lo -= 2; hi += 2; }
  const span = hi - lo; lo -= span * 0.12; hi += span * 0.12;
  const x = i => series.length === 1 ? W / 2 : padL + (i * (W - padL - padR)) / (series.length - 1);
  const y = v => padT + (H - padT - padB) * (1 - (v - lo) / (hi - lo));
  const grid = [0.25, 0.5, 0.75].map(t => {
    const gy = padT + (H - padT - padB) * t;
    return `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="var(--border)" stroke-width="1"/>`;
  }).join('');
  const pts = series.map((s, i) => `${x(i)},${y(s.value)}`).join(' ');
  const dots = series.map((s, i) => {
    const cx = x(i), cy = y(s.value);
    const mark = s.pr
      ? `<path d="M ${cx} ${cy - 6} L ${cx + 6} ${cy} L ${cx} ${cy + 6} L ${cx - 6} ${cy} Z" fill="var(--primary)" stroke="var(--bg)" stroke-width="1.5"/>`
      : `<circle cx="${cx}" cy="${cy}" r="4" fill="${color}" stroke="var(--bg)" stroke-width="1.5"/>`;
    const labelEvery = series.length > 8 ? Math.ceil(series.length / 8) : 1;
    const valLabel = (i % labelEvery === 0 || s.pr || i === series.length - 1)
      ? `<text x="${cx}" y="${cy - 10}" text-anchor="middle" font-size="9.5" fill="var(--text)" font-weight="600">${fmtKg(s.value)}</text>` : '';
    const xLabel = (i % labelEvery === 0 || i === series.length - 1)
      ? `<text x="${cx}" y="${H - 8}" text-anchor="middle" font-size="9" fill="var(--muted)">№${s.num}</text>` : '';
    return `${valLabel}${mark}${xLabel}<circle cx="${cx}" cy="${cy}" r="17" fill="transparent" data-action="open-workout" data-id="${s.workoutId}" style="cursor:pointer"><title>№${s.num}: ${fmtKg(s.value)} ${unit}${s.pr ? ' · PR' : ''}</title></circle>`;
  }).join('');
  return `<svg class="chart-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="График 1ПМ">
    ${grid}<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>${dots}</svg>`;
}

export function barChart(bars, { height = 200 } = {}) {
  if (!bars.length) return empty('📊', 'Пока нет тренировок');
  const W = 360, H = height, padL = 8, padR = 8, padT = 24, padB = 24;
  const max = Math.max(...bars.map(b => b.value), 1);
  const n = bars.length;
  const slot = (W - padL - padR) / n;
  const bw = Math.min(34, slot * 0.62);
  const items = bars.map((b, i) => {
    const cx = padL + slot * i + slot / 2;
    const bh = Math.max(3, (H - padT - padB) * (b.value / max));
    const by = H - padB - bh;
    return `<rect x="${cx - bw / 2}" y="${by}" width="${bw}" height="${bh}" rx="4" fill="${b.color}"/>
      <text x="${cx}" y="${by - 6}" text-anchor="middle" font-size="9" fill="var(--text)" font-weight="600">${compactTon(b.value)}</text>
      <text x="${cx}" y="${H - 7}" text-anchor="middle" font-size="9" fill="var(--muted)">№${b.num}</text>
      <rect x="${cx - slot / 2}" y="0" width="${slot}" height="${H}" fill="transparent" data-action="open-workout" data-id="${b.workoutId}" style="cursor:pointer"><title>№${b.num}: ${fmtInt(b.value)} кг</title></rect>`;
  }).join('');
  return `<svg class="chart-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Тоннаж по тренировкам">${items}</svg>`;
}

export function corridorChart(vol, groups, { min = 10, max = 20 } = {}) {
  const scaleMax = Math.max(max + 4, ...groups.map(g => vol[g] ?? 0));
  const rows = groups.map(g => {
    const v = vol[g] ?? 0;
    const pct = (v / scaleMax) * 100;
    const inRange = v >= min && v <= max;
    const color = v === 0 ? 'var(--border)' : inRange ? 'var(--success)' : v < min ? 'var(--legs)' : 'var(--danger)';
    const flag = v === 0 ? '' : inRange ? '' : v < min ? ' ⚠ мало' : ' ⚠ много';
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:.8rem;margin-bottom:4px">
        <span>${g}<span class="muted">${flag}</span></span><b class="mono">${v}</b>
      </div>
      <div style="position:relative;height:14px;border-radius:7px;background:var(--surface2);overflow:hidden">
        <div style="position:absolute;left:${(min / scaleMax) * 100}%;width:${((max - min) / scaleMax) * 100}%;top:0;bottom:0;background:rgba(63,185,80,.18);border-left:1.5px dashed var(--success);border-right:1.5px dashed var(--success)"></div>
        <div style="position:absolute;left:0;top:0;bottom:0;width:${pct}%;background:${color};border-radius:7px"></div>
      </div>
    </div>`;
  }).join('');
  return `<div>${rows}<div class="legend"><span><span class="dot" style="background:rgba(63,185,80,.4)"></span>цель ${min}–${max} подходов/нед</span></div></div>`;
}

export function scatterChart(pairs, { height = 190 } = {}) {
  if (pairs.length < 2) return empty('😴', 'Мало данных', 'Нужны сон и тоннаж в одни и те же дни (минимум 2)');
  const W = 360, H = height, padL = 34, padR = 12, padT = 14, padB = 28;
  const xs = pairs.map(p => p.hours), ys = pairs.map(p => p.tonnage);
  const xlo = Math.min(...xs) - 0.5, xhi = Math.max(...xs) + 0.5;
  const yhi = Math.max(...ys) * 1.1 || 1;
  const x = h => padL + (W - padL - padR) * ((h - xlo) / (xhi - xlo));
  const y = t => padT + (H - padT - padB) * (1 - t / yhi);
  const dots = pairs.map(p =>
    `<circle cx="${x(p.hours)}" cy="${y(p.tonnage)}" r="6" fill="var(--sleep)" opacity=".85"><title>${p.date}: ${fmtKg(p.hours)} ч → ${fmtInt(p.tonnage)} кг</title></circle>`).join('');
  return `<svg class="chart-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Сон и тоннаж">
    <line x1="${padL}" y1="${H - padB}" x2="${W - padR}" y2="${H - padB}" stroke="var(--border)"/>
    <line x1="${padL}" y1="${padT}" x2="${padL}" y2="${H - padB}" stroke="var(--border)"/>
    ${[xlo + 0.5, (xlo + xhi) / 2, xhi - 0.5].map(h => `<text x="${x(h)}" y="${H - 9}" text-anchor="middle" font-size="9" fill="var(--muted)">${fmtKg(Math.round(h * 2) / 2)} ч</text>`).join('')}
    <text x="${padL - 6}" y="${padT + 8}" text-anchor="end" font-size="9" fill="var(--muted)">${compactTon(yhi)}</text>
    ${dots}</svg>`;
}

export function weightChart(records, tonnageByDate, { height = 200 } = {}) {
  if (!records.length) return empty('⚖️', 'Записей пока нет', 'Первый замер появится на графике');
  const W = 360, H = height, padL = 34, padR = 12, padT = 20, padB = 26;
  const vals = records.map(r => r.weightKg);
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (hi - lo < 0.4) { lo -= 0.6; hi += 0.6; }
  const span = hi - lo; lo -= span * 0.15; hi += span * 0.15;
  const x = i => records.length === 1 ? W / 2 : padL + (i * (W - padL - padR)) / (records.length - 1);
  const y = v => padT + (H - padT - padB) * (1 - (v - lo) / (hi - lo));
  const maxTon = Math.max(...records.map(r => tonnageByDate.get(r.date) ?? 0), 1);
  const bars = records.map((r, i) => {
    const t = tonnageByDate.get(r.date) ?? 0;
    if (!t) return '';
    const bh = (H - padT - padB) * 0.5 * (t / maxTon);
    return `<rect x="${x(i) - 7}" y="${H - padB - bh}" width="14" height="${bh}" rx="3" fill="var(--legs)" opacity=".22"><title>${r.date}: тоннаж ${fmtInt(t)} кг</title></rect>`;
  }).join('');
  const pts = records.map((r, i) => `${x(i)},${y(r.weightKg)}`).join(' ');
  const dots = records.map((r, i) => {
    const every = records.length > 8 ? Math.ceil(records.length / 8) : 1;
    const lbl = (i % every === 0 || i === records.length - 1)
      ? `<text x="${x(i)}" y="${y(r.weightKg) - 9}" text-anchor="middle" font-size="9.5" fill="var(--text)" font-weight="600">${fmtKg(r.weightKg)}</text>` : '';
    return `${lbl}<circle cx="${x(i)}" cy="${y(r.weightKg)}" r="4" fill="var(--body)" stroke="var(--bg)" stroke-width="1.5"/>`;
  }).join('');
  const xLabels = [0, records.length - 1].filter((v, i, a) => a.indexOf(v) === i).map(i =>
    `<text x="${x(i)}" y="${H - 8}" text-anchor="${i === 0 ? 'start' : 'end'}" font-size="9" fill="var(--muted)">${records[i].date.slice(8, 10)}.${records[i].date.slice(5, 7)}</text>`).join('');
  return `<svg class="chart-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Вес тела">
    ${bars}<polyline points="${pts}" fill="none" stroke="var(--body)" stroke-width="2.5" stroke-linejoin="round"/>${dots}${xLabels}
    <text x="${padL - 4}" y="${padT}" text-anchor="end" font-size="9" fill="var(--muted)">${fmtKg(hi)}</text>
    <text x="${padL - 4}" y="${H - padB}" text-anchor="end" font-size="9" fill="var(--muted)">${fmtKg(lo)}</text></svg>`;
}

export function sleepBars(records, { height = 150 } = {}) {
  if (!records.length) return empty('🌙', 'Записей сна пока нет');
  const W = 360, H = height, padB = 22, padT = 18;
  const max = Math.max(9, ...records.map(r => r.hours));
  const slot = W / records.length;
  const bw = Math.min(26, slot * 0.6);
  return `<svg class="chart-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Сон по ночам">
    <line x1="0" y1="${H - padB - (H - padT - padB) * (6 / max)}" x2="${W}" y2="${H - padB - (H - padT - padB) * (6 / max)}" stroke="var(--danger)" stroke-dasharray="4 4" opacity=".6"/>
    ${records.map((r, i) => {
      const cx = slot * i + slot / 2;
      const bh = Math.max(3, (H - padT - padB) * (r.hours / max));
      const short = r.hours < 6;
      return `<rect x="${cx - bw / 2}" y="${H - padB - bh}" width="${bw}" height="${bh}" rx="4" fill="${short ? 'var(--danger)' : 'var(--sleep)'}" opacity="${short ? 1 : 0.85}"/>
        <text x="${cx}" y="${H - padB - bh - 5}" text-anchor="middle" font-size="8.5" fill="var(--text)">${fmtKg(r.hours)}</text>
        <text x="${cx}" y="${H - 7}" text-anchor="middle" font-size="8" fill="var(--muted)">${r.date.slice(8, 10)}</text>`;
    }).join('')}</svg>`;
}

export { esc };
