// ПОДХОД · сон и восстановление (FR-19): часы + качество за два тапа
import { state, upsertSleep, deleteSleep, notify } from '../core/store.js';
import { todayISO, fmtDate, fmtKg, escapeHtml } from '../core/util.js';
import { icon, stepper, scaleRow, empty, sleepBars } from './components.js';

let date = todayISO();
let hours = 8;
let quality = 4;
let savedAt = 0;

function loadForDate() {
  const rec = state.sleep.find(s => s.date === date);
  hours = rec?.hours ?? 8;
  quality = rec?.quality ?? 4;
}

export function render() {
  const records = [...state.sleep].sort((a, b) => a.date.localeCompare(b.date)).slice(-14);
  const all = [...state.sleep].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
  const rec = state.sleep.find(s => s.date === date);

  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="nav" data-to="more" aria-label="Назад">${icon('chevL')}</button>
    <h1>Сон</h1>
  </div>

  ${Date.now() - savedAt < 2500 ? `<div class="banner" style="border-color:var(--success)">${icon('check')} Сохранено</div>` : ''}

  <div class="card">
    <div class="field-label" style="margin-top:0"><span>Ночь (дата пробуждения)</span>${rec ? '<span class="muted">запись есть — правим</span>' : ''}</div>
    <input type="date" value="${date}" data-change="sleep-date" max="${todayISO()}">
    <div id="sleep-form">${formBody()}</div>
    <div style="height:14px"></div>
    <button class="btn primary big" data-action="save-sleep" style="background:var(--sleep);border-color:var(--sleep);color:#fff">${icon('check')} Сохранить</button>
    ${hours < 6 ? `<p class="small" style="color:var(--danger);margin-bottom:0">⚠ Меньше 6 часов — недосып отметится в аналитике.</p>` : ''}
  </div>

  <div class="chart-card">
    <h3>Последние ${records.length || 0} ночей</h3>
    <div class="chart-sub">красный столбец и пунктир — граница 6 часов</div>
    ${sleepBars(records)}
  </div>

  <div class="section-title">Записи</div>
  ${all.length ? `<div class="card" style="padding:4px 16px">${all.map(s => `
    <div class="list-row">
      <div class="grow"><div class="title mono" style="color:${s.hours < 6 ? 'var(--danger)' : 'var(--sleep)'}">${fmtKg(s.hours)} ч · ${s.quality}/5</div>
      <div class="sub">${fmtDate(s.date)}${s.hours < 6 ? ' · недосып' : ''}</div></div>
      <button class="icon-btn plain" data-action="del-sleep" data-id="${s.id}" aria-label="Удалить запись" style="color:var(--danger)">${icon('trash')}</button>
    </div>`).join('')}</div>` : empty('🌙', 'Записей пока нет', 'Отметьте прошлую ночь — виджет появится на «Сегодня»')}
  <p class="muted tiny">Связь «сон ↔ тоннаж» — на вкладке Аналитика.</p>`;
}

function formBody() {
  return `
  ${stepper({ key: 'hours', label: 'Часы сна', value: hours, unit: 'ч', step: 0.5, min: 0, max: 14 })}
  <div class="field-label"><span>Качество</span><span class="muted">1 — разбитость, 5 — огонь</span></div>
  ${scaleRow('quality', [1, 2, 3, 4, 5], quality)}`;
}

const refreshForm = () => {
  const el = document.getElementById('sleep-form');
  if (el) el.innerHTML = formBody();
};

export const actions = {
  'sleep-date': el => { date = el.value || todayISO(); loadForDate(); notify(); },
  step: el => {
    if (el.dataset.key !== 'hours') return;
    hours = Math.min(14, Math.max(0, Math.round((hours + parseFloat(el.dataset.delta)) * 2) / 2));
    refreshForm();
  },
  quality: el => { quality = +el.dataset.value; refreshForm(); },
  'save-sleep': async () => {
    if (!(hours > 0)) return;
    await upsertSleep({ date, hours, quality });
    savedAt = Date.now();
    notify();
  },
  'del-sleep': el => deleteSleep(el.dataset.id),
};
export const inputs = {
  stepval: el => {
    if (el.dataset.key !== 'hours') return;
    const v = parseFloat(el.value.replace(',', '.'));
    if (Number.isFinite(v)) { hours = Math.min(14, Math.max(0, v)); }
  },
};

// при первом рендере подставляем значения существующей записи
loadForDate();
