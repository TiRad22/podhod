// ПОДХОД · аналитика: неделя, 1ПМ, тоннаж, объём по группам, сон↔тоннаж (FR-13…16, FR-19)
import { state, notify } from '../core/store.js';
import { fmtInt, escapeHtml, todayISO } from '../core/util.js';
import { SPLITS } from '../core/scheduler.js';
import { weeklySummary, oneRmSeries, tonnageSeries, volumeByGroup, VOLUME_TARGET, sleepTonnagePairs } from '../core/analytics.js';
import { GROUPS } from '../core/seed.js';
import { icon, lineChart, barChart, corridorChart, scatterChart, empty } from './components.js';
import { deltaBadge } from './today.js';

let exId = null;

function exercisesWithData() {
  const ids = new Set(state.entries.filter(e => state.sets.some(s => s.entryId === e.id)).map(e => e.exerciseId));
  return state.exercises.filter(e => ids.has(e.id)).sort((a, b) => a.name.localeCompare(b.name, 'ru'));
}

export function render() {
  const today = todayISO();
  const sum = weeklySummary(state, today, state.settings.schedule);
  const withData = exercisesWithData();
  if (!exId || !withData.some(e => e.id === exId)) exId = withData[0]?.id ?? null;
  const rm = exId ? oneRmSeries(exId, state) : [];
  const tons = tonnageSeries(state).slice(-12);
  const vol = volumeByGroup(state, today);
  const pairs = state.settings.flags.sleep ? sleepTonnagePairs(state) : [];

  return `
  <div class="page-head"><h1>Аналитика</h1><span class="spacer"></span><span class="muted small">обновляется сразу</span></div>

  <div class="tiles">
    <div class="tile"><div class="tile-l">Тоннаж · 7 дней</div><div class="tile-v">${fmtInt(sum.tonnage)}<span class="muted" style="font-size:.85rem"> кг</span>${deltaBadge(sum.delta)}</div></div>
    <div class="tile"><div class="tile-l">Подходы · 7 дней</div><div class="tile-v">${sum.sets}</div></div>
    <div class="tile"><div class="tile-l">Тренировки</div><div class="tile-v">${sum.workouts}</div></div>
    <div class="tile"><div class="tile-l">Серия по плану</div><div class="tile-v">🔥 ${sum.streak}</div></div>
  </div>

  <div class="chart-card">
    <h3>Лучший 1ПМ по тренировкам</h3>
    <div class="chart-sub">формула Эпли · ромб ◆ = рекорд · тап по точке → тренировка</div>
    ${withData.length ? `
    <select data-change="pick-ex" style="margin-bottom:10px" aria-label="Упражнение">
      ${withData.map(e => `<option value="${e.id}" ${e.id === exId ? 'selected' : ''}>${escapeHtml(e.name)}</option>`).join('')}
    </select>
    ${lineChart(rm)}` : empty('📈', 'Нет данных', 'Завершите тренировку — график оживёт')}
  </div>

  <div class="chart-card">
    <h3>Тоннаж по тренировкам</h3>
    <div class="chart-sub">последние ${tons.length || 0} · тап по столбцу → карточка</div>
    ${barChart(tons.map(t => ({ ...t, value: t.tonnage, color: SPLITS[t.split]?.color ?? 'var(--muted)' })))}
    <div class="legend">
      ${Object.entries(SPLITS).map(([k, v]) => `<span><span class="dot" style="background:${v.color}"></span>${v.label}</span>`).join('')}
    </div>
  </div>

  <div class="chart-card">
    <h3>Объём по мышечным группам</h3>
    <div class="chart-sub">рабочие подходы за 7 дней · коридор ${VOLUME_TARGET.min}–${VOLUME_TARGET.max}</div>
    ${corridorChart(vol, GROUPS, VOLUME_TARGET)}
  </div>

  ${state.settings.flags.sleep ? `
  <div class="chart-card">
    <h3>Сон ↔ тоннаж</h3>
    <div class="chart-sub">каждая точка — день с записанным сном и тренировкой</div>
    ${scatterChart(pairs)}
  </div>` : ''}
  `;
}

export const actions = {
  'pick-ex': el => { exId = el.value; notify(); },
};
