// ПОДХОД · вес тела и замеры (FR-18): запись ≤ 15 с, график 1/3/6 мес рядом с тоннажом
import { state, upsertBody, deleteBody, notify } from '../core/store.js';
import { todayISO, fmtDate, addDaysISO, escapeHtml, fmtKg } from '../core/util.js';
import { tonnageSeries } from '../core/analytics.js';
import { icon, empty, weightChart } from './components.js';

let date = todayISO();
let range = 3; // месяцев
let savedAt = 0;

const MEASURES = [['waistCm', 'Талия'], ['chestCm', 'Грудь'], ['armCm', 'Рука'], ['thighCm', 'Бедро']];

export function render() {
  const rec = state.body.find(b => b.date === date);
  const from = addDaysISO(todayISO(), -range * 30);
  const records = state.body.filter(b => b.date >= from).sort((a, b) => a.date.localeCompare(b.date));
  const tonByDate = new Map(tonnageSeries(state).map(t => [t.date, t.tonnage]));
  const all = [...state.body].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);

  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="nav" data-to="more" aria-label="Назад">${icon('chevL')}</button>
    <h1>Вес и замеры</h1>
  </div>

  ${Date.now() - savedAt < 2500 ? `<div class="banner" style="border-color:var(--success)">${icon('check')} Сохранено</div>` : ''}

  <div class="card">
    <div class="field-label" style="margin-top:0"><span>Дата</span></div>
    <input type="date" value="${date}" data-change="body-date" max="${todayISO()}">
    <div class="field-label"><span>Вес тела</span><span class="muted">кг</span></div>
    <input id="body-weight" inputmode="decimal" style="font-family:var(--font-display);font-size:1.4rem;text-align:center" placeholder="82,5" value="${rec ? fmtKg(rec.weightKg) : ''}">
    <details style="margin-top:10px">
      <summary class="muted small" style="cursor:pointer;min-height:40px;display:flex;align-items:center">Замеры (опционально) — можно пропускать</summary>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px">
        ${MEASURES.map(([k, l]) => `<div><div class="field-label" style="margin:0 0 4px"><span>${l}, см</span></div>
          <input id="body-${k}" inputmode="decimal" value="${rec?.[k] != null ? fmtKg(rec[k]) : ''}" placeholder="—"></div>`).join('')}
      </div>
    </details>
    <div style="height:14px"></div>
    <button class="btn primary big" data-action="save-body" style="background:var(--body);border-color:var(--body)">${icon('check')} Сохранить</button>
  </div>

  <div class="chart-card">
    <h3>Динамика веса</h3>
    <div class="chart-sub">жёлтые столбцы — тоннаж тренировок в тот же день</div>
    <div class="filter-row">${[1, 3, 6].map(m => `<button class="f-chip${range === m ? ' active' : ''}" data-action="range" data-m="${m}">${m} мес</button>`).join('')}</div>
    ${weightChart(records, tonByDate)}
  </div>

  <div class="section-title">Последние записи</div>
  ${all.length ? `<div class="card" style="padding:4px 16px">${all.map(b => `
    <div class="list-row">
      <div class="grow"><div class="title mono">${fmtKg(b.weightKg)} кг</div>
      <div class="sub">${fmtDate(b.date)}${MEASURES.filter(([k]) => b[k] != null).map(([k, l]) => ` · ${l.toLowerCase()} ${fmtKg(b[k])}`).join('')}</div></div>
      <button class="icon-btn plain" data-action="del-body" data-id="${b.id}" aria-label="Удалить запись" style="color:var(--danger)">${icon('trash')}</button>
    </div>`).join('')}</div>` : empty('⚖️', 'Записей пока нет')}
  `;
}

const numOrNull = id => {
  const v = parseFloat(document.getElementById(id)?.value.replace(',', '.'));
  return Number.isFinite(v) && v > 0 ? v : null;
};

export const actions = {
  'body-date': el => { date = el.value || todayISO(); notify(); },
  range: el => { range = +el.dataset.m; notify(); },
  'save-body': async () => {
    const w = numOrNull('body-weight');
    if (!w) { document.getElementById('body-weight').focus(); return; }
    const rec = { date, weightKg: w };
    for (const [k] of MEASURES) { const v = numOrNull(`body-${k}`); if (v != null) rec[k] = v; }
    await upsertBody(rec);
    savedAt = Date.now();
    notify();
  },
  'del-body': el => deleteBody(el.dataset.id),
};
