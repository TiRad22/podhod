// ПОДХОД · журнал активной тренировки (FR-02…08, FR-12, FR-28)
import {
  state, draft, workoutById, exerciseById, entriesOf, setsOf, ghostsFor,
  addSet, updateSet, removeSet, repeatAll, addExerciseToDraft, moveEntry, removeEntry,
  finishDraft, discardDraft, updateWorkout, startRest, addExercise, startWorkout,
} from '../core/store.js';
import { fmtKg, fmtInt, fmtDate, fmtElapsed, escapeHtml, normName, clamp, round2 } from '../core/util.js';
import { SPLITS, SPLIT_KEYS } from '../core/scheduler.js';
import { workoutStats } from '../core/analytics.js';
import { setNotation } from '../core/format.js';
import { GROUPS, EQUIPMENT } from '../core/seed.js';
import { navigate } from './router.js';
import { icon, plateNum, splitTag, setChip, stepper, scaleRow, empty, openModal, closeModal, setModalBody, celebrate } from './components.js';

let editor = null;      // {entryId, groupId?, weightKg, reps, count, rpe, failure}
let finishEnergy = null;
let finishNote = '';
let picker = { q: '', group: 'Все', creating: false };

export function render() {
  const w = draft();
  if (!w) return `
    ${empty('🏋️', 'Нет активной тренировки', 'Начните с экрана «Сегодня»')}
    <button class="btn primary big" data-action="start-here">${icon('play')} Начать сейчас</button>`;

  const entries = entriesOf(w.id);
  const stats = workoutStats(w.id, state.entries, state.sets);

  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="nav" data-to="today" aria-label="Свернуть (таймер продолжит идти)">${icon('chevL')}</button>
    ${plateNum(w.num, w.split)}
    <div class="grow" style="flex:1;min-width:0">
      <h1 style="font-size:1.1rem">№${w.num} ${splitTag(w.split)}</h1>
      <button class="muted small" style="background:none;border:none;padding:0;cursor:pointer" data-action="edit-meta">${fmtDate(w.date)} · изменить</button>
    </div>
    <div class="display" style="font-size:1.15rem;color:var(--success)" data-elapsed-start="${w.startedAt}" aria-label="Длительность">${fmtElapsed(Date.now() - w.startedAt)}</div>
  </div>

  ${entries.length === 0 ? empty('📋', 'Добавьте первое упражнение', 'Прошлые веса появятся призраками — повтор в один тап') : ''}

  ${entries.map(e => exerciseCard(e)).join('')}

  <button class="btn big" data-action="pick-exercise" style="margin-bottom:10px">${icon('plus')} Упражнение</button>
  <button class="btn primary big" data-action="finish">${icon('check')} Завершить · ${stats.sets} подх. · ${fmtInt(stats.tonnage)} кг</button>
  <p class="muted tiny" style="text-align:center;margin-top:10px">Автосохранение включено · сворачивание не останавливает таймер</p>
  `;
}

function exerciseCard(e) {
  const ex = exerciseById(e.exerciseId);
  const real = setsOf(e.id);
  const ghosts = ghostsFor(e);
  const ghostCount = ghosts.reduce((t, g) => t + g.count, 0);
  return `
  <div class="card" data-entry="${e.id}">
    <div class="card-head">
      <div class="grow" style="flex:1;min-width:0"><h3>${escapeHtml(ex?.name ?? 'Упражнение')}</h3></div>
      <span class="group-tag">${ex?.group ?? ''}</span>
    </div>
    <div class="set-row">
      ${real.map(g => setChip(g, { action: 'edit-set', attrs: `data-id="${g.id}"` })).join('')}
      ${ghosts.map(g => setChip(g, { ghost: true, action: 'ghost', attrs: `data-entry="${e.id}" data-w="${g.weightKg}" data-r="${g.reps}" data-c="${g.count}"` })).join('')}
      ${!real.length && !ghosts.length ? '<span class="muted small">Подходов пока нет</span>' : ''}
    </div>
    <div class="btn-row" style="align-items:center">
      <button class="btn small-btn" data-action="add-set" data-entry="${e.id}" style="flex:0 1 auto">${icon('plus')} Подход</button>
      ${ghostCount ? `<button class="btn small-btn ghost" data-action="repeat-all" data-entry="${e.id}" style="color:var(--primary);flex:0 1 auto">${icon('repeat')} Всё ·${ghostCount}</button>` : ''}
      <button class="icon-btn plain" data-action="move-up" data-id="${e.id}" aria-label="Выше" style="margin-left:auto">${icon('up')}</button>
      <button class="icon-btn plain" data-action="move-down" data-id="${e.id}" aria-label="Ниже">${icon('down')}</button>
      <button class="icon-btn plain" data-action="remove-entry" data-id="${e.id}" aria-label="Удалить упражнение" style="color:var(--danger)">${icon('trash')}</button>
    </div>
  </div>`;
}

/* ── Редактор подхода (шторка) ── */
function editorBody() {
  const ex = exerciseById(state.entries.find(e => e.id === editor.entryId)?.exerciseId);
  const g = { weightKg: editor.weightKg, reps: editor.reps, count: editor.count };
  return `
  <div class="modal-title">${escapeHtml(ex?.name ?? 'Подход')}<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
  <div class="modal-sub">${editor.groupId ? 'Правка группы подходов' : 'Новая группа подходов'}</div>
  ${stepper({ key: 'weightKg', label: 'Вес', value: editor.weightKg, unit: 'кг', step: 2.5, min: 0, max: 500, hint: '0 = свой вес', fine: true })}
  ${stepper({ key: 'reps', label: 'Повторы', value: editor.reps, unit: 'повт', step: 1, min: 1, max: 100 })}
  ${stepper({ key: 'count', label: 'Одинаковых подходов', value: editor.count, unit: 'шт', step: 1, min: 1, max: 50, hint: '«39 кг на 11 2»' })}
  ${state.settings.flags.rpe ? `
    <div class="field-label"><span>RPE (опционально)</span></div>
    ${scaleRow('rpe', [6, 7, 8, 9, 10], editor.rpe)}
    <div class="toggle-row" style="border:none"><div class="grow"><div class="t-label">До отказа</div></div>
      <button class="switch" role="switch" aria-checked="${editor.failure}" data-action="failure"></button></div>` : ''}
  <div class="notation-preview" id="notation-preview">${setNotation(g)}</div>
  <div style="height:14px"></div>
  <div class="btn-row">
    ${editor.groupId ? `<button class="btn danger" data-action="delete-set" style="flex:0 0 auto">${icon('trash')}</button>` : ''}
    <button class="btn primary big" data-action="save-set">${icon('check')} ${editor.groupId ? 'Сохранить' : 'Записать'}</button>
  </div>`;
}

function openEditor(entryId, groupId = null) {
  const real = setsOf(entryId);
  const g = groupId ? state.sets.find(s => s.id === groupId) : null;
  const last = real[real.length - 1];
  const ghost = ghostsFor(state.entries.find(e => e.id === entryId))[0];
  const base = g ?? last ?? ghost ?? { weightKg: 20, reps: 10, count: 1 };
  editor = {
    entryId, groupId,
    weightKg: base.weightKg, reps: base.reps, count: g ? g.count : (last ? 1 : base.count ?? 1),
    rpe: g?.rpe ?? null, failure: g?.failure ?? false,
  };
  openModal({ html: `<div id="editor-body">${editorBody()}</div>`, actions: editorActions, inputs: editorInputs });
}

function refreshEditor() { setModalBody('editor-body', editorBody()); }
function refreshPreview() {
  const el = document.getElementById('notation-preview');
  if (el) el.textContent = setNotation({ weightKg: Number(editor.weightKg) || 0, reps: Math.round(Number(editor.reps)) || 0, count: Math.round(Number(editor.count)) || 1 });
}

const editorActions = {
  step: el => {
    const key = el.dataset.key;
    const delta = parseFloat(el.dataset.delta);
    const lim = key === 'weightKg' ? [0, 500] : key === 'reps' ? [1, 100] : [1, 50];
    editor[key] = round2(clamp((Number(editor[key]) || 0) + delta, lim[0], lim[1]));
    refreshEditor();
  },
  setval: el => { editor[el.dataset.key] = parseFloat(el.dataset.value); refreshEditor(); },
  rpe: el => { const v = +el.dataset.value; editor.rpe = editor.rpe === v ? null : v; refreshEditor(); },
  failure: () => { editor.failure = !editor.failure; refreshEditor(); },
  'save-set': async () => {
    const payload = {
      weightKg: editor.weightKg, reps: editor.reps, count: editor.count,
      rpe: editor.rpe, failure: editor.failure,
    };
    let res;
    if (editor.groupId) { await updateSet(editor.groupId, payload); res = { isPR: state.sets.find(s => s.id === editor.groupId)?.pr, oneRm: 0 }; }
    else res = await addSet(editor.entryId, payload);
    closeModal();
    afterSet(res);
  },
  'delete-set': async () => { const id = editor.groupId; closeModal(); await removeSet(id); },
};
const editorInputs = {
  stepval: el => {
    const v = parseFloat(el.value.replace(',', '.'));
    editor[el.dataset.key] = Number.isFinite(v) ? v : 0;
    refreshPreview();
  },
};

function afterSet(res) {
  if (res?.isPR) celebrate(res.oneRm || 0);
  if (state.settings.autoRest) startRest();
}

/* ── Выбор упражнения из каталога (≤ 3 тапа) ── */
function pickerBody() {
  if (picker.creating) return `
    <div class="modal-title">Своё упражнение<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
    <div class="field-label">Название</div>
    <input id="new-ex-name" placeholder="Например: Тяга каната" autocomplete="off">
    <div class="field-label">Мышечная группа</div>
    <select id="new-ex-group">${GROUPS.map(g => `<option>${g}</option>`).join('')}</select>
    <div class="field-label">Снаряд</div>
    <select id="new-ex-eq">${EQUIPMENT.map(g => `<option>${g}</option>`).join('')}</select>
    <div style="height:16px"></div>
    <div class="btn-row">
      <button class="btn" data-action="picker-back">Назад</button>
      <button class="btn primary" data-action="create-pick">${icon('check')} Создать и добавить</button>
    </div>`;
  const q = normName(picker.q);
  const list = state.exercises
    .filter(e => (picker.group === 'Все' || e.group === picker.group))
    .filter(e => !q || normName(e.name).includes(q) || (e.aliases ?? []).some(a => normName(a).includes(q)))
    .sort((a, b) => a.name.localeCompare(b.name, 'ru'));
  const used = new Set(entriesOf(state.draftId).map(e => e.exerciseId));
  return `
    <div class="modal-title">Упражнение<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
    <div class="search-wrap">${icon('search')}<input id="picker-q" data-input="picker-q" placeholder="Поиск по названию и алиасам" value="${escapeHtml(picker.q)}" autocomplete="off"></div>
    <div class="filter-row">${['Все', ...GROUPS].map(g => `<button class="f-chip${picker.group === g ? ' active' : ''}" data-action="picker-group" data-g="${g}">${g}</button>`).join('')}</div>
    <div id="picker-list" style="max-height:46dvh;overflow-y:auto">
      ${list.map(e => `<div class="list-row" data-action="pick" data-id="${e.id}" style="cursor:pointer">
        <div class="grow"><div class="title">${escapeHtml(e.name)}${used.has(e.id) ? ' <span class="muted tiny">· уже в тренировке</span>' : ''}</div><div class="sub">${e.equipment ?? ''}</div></div>
        <span class="group-tag">${e.group}</span></div>`).join('') || '<div class="empty small">Ничего не нашлось</div>'}
    </div>
    <div style="height:10px"></div>
    <button class="btn big" data-action="picker-create">${icon('plus')} Создать своё</button>`;
}

function openPicker() {
  picker = { q: '', group: 'Все', creating: false };
  openModal({
    html: `<div id="picker-body">${pickerBody()}</div>`,
    actions: {
      pick: async el => { closeModal(); await addExerciseToDraft(el.dataset.id); },
      'picker-group': el => { picker.group = el.dataset.g; setModalBody('picker-body', pickerBody()); },
      'picker-create': () => { picker.creating = true; setModalBody('picker-body', pickerBody()); document.getElementById('new-ex-name')?.focus(); },
      'picker-back': () => { picker.creating = false; setModalBody('picker-body', pickerBody()); },
      'create-pick': async () => {
        const name = document.getElementById('new-ex-name').value.trim();
        if (!name) { document.getElementById('new-ex-name').focus(); return; }
        const ex = await addExercise({
          name, group: document.getElementById('new-ex-group').value,
          equipment: document.getElementById('new-ex-eq').value,
        });
        closeModal();
        await addExerciseToDraft(ex.id);
      },
    },
    inputs: {
      'picker-q': el => {
        picker.q = el.value;
        const listEl = document.getElementById('picker-list');
        const q = normName(picker.q);
        const used = new Set(entriesOf(state.draftId).map(e => e.exerciseId));
        const list = state.exercises
          .filter(e => (picker.group === 'Все' || e.group === picker.group))
          .filter(e => !q || normName(e.name).includes(q) || (e.aliases ?? []).some(a => normName(a).includes(q)))
          .sort((a, b) => a.name.localeCompare(b.name, 'ru'));
        if (listEl) listEl.innerHTML = list.map(e => `<div class="list-row" data-action="pick" data-id="${e.id}" style="cursor:pointer">
          <div class="grow"><div class="title">${escapeHtml(e.name)}${used.has(e.id) ? ' <span class="muted tiny">· уже в тренировке</span>' : ''}</div><div class="sub">${e.equipment ?? ''}</div></div>
          <span class="group-tag">${e.group}</span></div>`).join('') || '<div class="empty small">Ничего не нашлось</div>';
      },
    },
  });
}

/* ── Финиш и сводка (FR-08, FR-20) ── */
function openFinish() {
  const w = draft();
  const stats = workoutStats(w.id, state.entries, state.sets);
  const hasSets = stats.sets > 0;
  finishEnergy = w.energy ?? null;
  finishNote = w.note ?? '';
  if (!hasSets) {
    openModal({
      sheet: false,
      html: `
      <div class="modal-title">Пустая тренировка</div>
      <div class="modal-sub">Ни одного подхода — такую тренировку не сохраняем. Удалить черновик №${w.num}?</div>
      <div class="btn-row">
        <button class="btn" data-action="modal-close">Продолжить</button>
        <button class="btn danger solid" data-action="discard">Удалить</button>
      </div>`,
      actions: { discard: async () => { closeModal(); await discardDraft(); navigate('today'); } },
    });
    return;
  }
  const prList = entriesOf(w.id).flatMap(e => setsOf(e.id).filter(g => g.pr).map(g =>
    `<div class="issue warn" style="color:var(--primary)"><span>★</span><span>${escapeHtml(exerciseById(e.exerciseId)?.name ?? '')} — ${setNotation(g)}</span></div>`)).join('');
  const durMin = Math.max(1, Math.round((Date.now() - w.startedAt) / 60000));
  openModal({
    html: `
    <div class="modal-title">Сводка · №${w.num} ${splitTag(w.split)}<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
    <div class="tiles" style="margin-top:12px">
      <div class="tile"><div class="tile-l">Длительность</div><div class="tile-v" style="font-size:1.2rem">${durMin} мин</div></div>
      <div class="tile"><div class="tile-l">Подходы</div><div class="tile-v" style="font-size:1.2rem">${stats.sets}</div></div>
      <div class="tile"><div class="tile-l">Тоннаж</div><div class="tile-v" style="font-size:1.2rem">${fmtInt(stats.tonnage)} кг</div></div>
      <div class="tile"><div class="tile-l">Рекорды</div><div class="tile-v" style="font-size:1.2rem;color:var(--primary)">★ ${stats.prs}</div></div>
    </div>
    ${prList}
    <div class="field-label"><span>Самочувствие (опционально)</span></div>
    <div id="energy-row">${scaleRow('energy', [1, 2, 3, 4, 5], finishEnergy, { 1: '1 😫', 2: '2', 3: '3', 4: '4', 5: '5 🔥' })}</div>
    <div class="field-label"><span>Заметка</span></div>
    <textarea id="finish-note" data-input="finish-note" rows="2" placeholder="например: плечо ныло">${escapeHtml(finishNote)}</textarea>
    <div style="height:14px"></div>
    <button class="btn primary big" data-action="save-finish">${icon('check')} Сохранить тренировку</button>`,
    actions: {
      energy: el => { const v = +el.dataset.value; finishEnergy = finishEnergy === v ? null : v; setModalBody('energy-row', scaleRow('energy', [1, 2, 3, 4, 5], finishEnergy, { 1: '1 😫', 2: '2', 3: '3', 4: '4', 5: '5 🔥' })); },
      'save-finish': async () => {
        const res = await finishDraft({ energy: finishEnergy, note: finishNote });
        closeModal();
        if (!res.empty) navigate('card', res.workout.id);
      },
    },
    inputs: { 'finish-note': el => { finishNote = el.value; } },
  });
}

export const actions = {
  'start-here': async () => { await startWorkout({}); },
  'add-set': el => openEditor(el.dataset.entry),
  'edit-set': el => {
    const g = state.sets.find(s => s.id === el.dataset.id);
    if (g) openEditor(g.entryId, g.id);
  },
  ghost: async el => {
    const res = await addSet(el.dataset.entry, { weightKg: +el.dataset.w, reps: +el.dataset.r, count: +el.dataset.c });
    afterSet(res);
  },
  'repeat-all': async el => {
    const res = await repeatAll(el.dataset.entry);
    if (res.added) { if (res.anyPR) celebrate(0); if (state.settings.autoRest) startRest(); }
  },
  'move-up': el => moveEntry(el.dataset.id, -1),
  'move-down': el => moveEntry(el.dataset.id, 1),
  'remove-entry': el => removeEntry(el.dataset.id),
  'pick-exercise': openPicker,
  finish: openFinish,
  'edit-meta': () => {
    const w = draft();
    openModal({
      html: `
      <div class="modal-title">Тренировка №${w.num}<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
      <div class="field-label">Дата</div><input type="date" id="meta-date" value="${w.date}">
      <div class="field-label">Сплит</div>
      <select id="meta-split">${SPLIT_KEYS.map(k => `<option value="${k}" ${k === w.split ? 'selected' : ''}>${SPLITS[k].label}</option>`).join('')}</select>
      <div class="field-label">Номер</div><input type="number" id="meta-num" inputmode="numeric" value="${w.num}" min="1">
      <div style="height:16px"></div>
      <button class="btn primary big" data-action="save-meta">${icon('check')} Сохранить</button>`,
      actions: {
        'save-meta': async () => {
          await updateWorkout(w.id, {
            date: document.getElementById('meta-date').value || w.date,
            split: document.getElementById('meta-split').value,
            num: Math.max(1, parseInt(document.getElementById('meta-num').value, 10) || w.num),
          });
          closeModal();
        },
      },
    });
  },
};
