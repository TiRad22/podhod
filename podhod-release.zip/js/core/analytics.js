// ПОДХОД · аналитика: тоннаж, 1ПМ Эпли, PR, неделя, объём (FR-12…16, §7)
import { addDaysISO, todayISO, round1, pctDelta } from './util.js';
import { streak } from './scheduler.js';

// 1ПМ по Эпли; при весе 0 (свой вес) тоннаж и 1ПМ не считаем
export const epley = (weightKg, reps) =>
  weightKg > 0 ? weightKg * (1 + reps / 30) : 0;

export const groupTonnage = g => g.weightKg * g.reps * g.count;
export const groupSets = g => g.count;

export function workoutStats(workoutId, entries, sets) {
  const eids = new Set(entries.filter(e => e.workoutId === workoutId).map(e => e.id));
  const gs = sets.filter(s => eids.has(s.entryId));
  return {
    tonnage: gs.reduce((t, g) => t + groupTonnage(g), 0),
    sets: gs.reduce((t, g) => t + g.count, 0),
    prs: gs.filter(g => g.pr).length,
    groups: gs.length,
  };
}

// Лучший 1ПМ упражнения по завершённым тренировкам (вся история).
// excludeWorkoutId — чтобы не сравнивать с самой собой при правке.
export function best1pm(exerciseId, { workouts, entries, sets }, excludeWorkoutId = null) {
  const finished = new Set(workouts.filter(w => w.finishedAt && w.id !== excludeWorkoutId).map(w => w.id));
  const eids = new Set(entries.filter(e => e.exerciseId === exerciseId && finished.has(e.workoutId)).map(e => e.id));
  let best = 0;
  for (const g of sets) if (eids.has(g.entryId)) best = Math.max(best, epley(g.weightKg, g.reps));
  return best;
}

// PR: строго бьём существующий рекорд (первое знакомство с упражнением — не PR)
export const isPR = (weightKg, reps, prevBest) =>
  weightKg > 0 && prevBest > 0 && epley(weightKg, reps) > prevBest + 1e-9;

// Линия лучшего 1ПМ по тренировкам для упражнения; PR-точки помечены
export function oneRmSeries(exerciseId, data) {
  const { workouts, entries, sets } = data;
  const byWorkout = new Map();
  for (const e of entries) {
    if (e.exerciseId !== exerciseId) continue;
    const gs = sets.filter(s => s.entryId === e.id);
    if (!gs.length) continue;
    const best = gs.reduce((m, g) => Math.max(m, epley(g.weightKg, g.reps)), 0);
    byWorkout.set(e.workoutId, Math.max(byWorkout.get(e.workoutId) ?? 0, best));
  }
  const ws = workouts
    .filter(w => w.finishedAt && byWorkout.has(w.id))
    .sort((a, b) => a.date.localeCompare(b.date) || a.num - b.num);
  let running = 0;
  return ws.map(w => {
    const v = byWorkout.get(w.id);
    const pr = running > 0 && v > running + 1e-9;
    running = Math.max(running, v);
    return { workoutId: w.id, num: w.num, date: w.date, value: round1(v), pr };
  });
}

export const tonnageSeries = data =>
  data.workouts
    .filter(w => w.finishedAt)
    .sort((a, b) => a.date.localeCompare(b.date) || a.num - b.num)
    .map(w => ({ workoutId: w.id, num: w.num, date: w.date, split: w.split, ...workoutStats(w.id, data.entries, data.sets) }));

// Окно [today-6 … today] включительно
export function windowWorkouts(data, today = todayISO(), days = 7, offset = 0) {
  const to = addDaysISO(today, -offset);
  const from = addDaysISO(to, -(days - 1));
  return data.workouts.filter(w => w.finishedAt && w.date >= from && w.date <= to);
}

export function weeklySummary(data, today = todayISO(), schedule) {
  const cur = windowWorkouts(data, today, 7, 0);
  const prev = windowWorkouts(data, today, 7, 7);
  const sum = ws => ws.reduce((a, w) => {
    const s = workoutStats(w.id, data.entries, data.sets);
    return { tonnage: a.tonnage + s.tonnage, sets: a.sets + s.sets };
  }, { tonnage: 0, sets: 0 });
  const c = sum(cur), p = sum(prev);
  return {
    tonnage: c.tonnage, sets: c.sets, workouts: cur.length,
    delta: pctDelta(c.tonnage, p.tonnage),
    streak: streak(data.workouts, schedule, today),
  };
}

// Рабочие подходы по мышечным группам за 7 дней, коридор 10–20
export function volumeByGroup(data, today = todayISO(), days = 7) {
  const ws = new Set(windowWorkouts(data, today, days).map(w => w.id));
  const exGroup = new Map(data.exercises.map(e => [e.id, e.group]));
  const entryGroup = new Map();
  for (const e of data.entries) if (ws.has(e.workoutId)) entryGroup.set(e.id, exGroup.get(e.exerciseId));
  const out = {};
  for (const g of data.sets) {
    const gr = entryGroup.get(g.entryId);
    if (gr) out[gr] = (out[gr] ?? 0) + g.count;
  }
  return out; // { 'Грудь': 12, ... }
}
export const VOLUME_TARGET = { min: 10, max: 20 };

// Сон ↔ тоннаж: пары по дате (FR-19)
export function sleepTonnagePairs(data) {
  const byDate = new Map();
  for (const t of tonnageSeries(data)) byDate.set(t.date, (byDate.get(t.date) ?? 0) + t.tonnage);
  return data.sleep
    .filter(s => byDate.has(s.date))
    .map(s => ({ date: s.date, hours: s.hours, quality: s.quality, tonnage: byDate.get(s.date) }))
    .sort((a, b) => a.date.localeCompare(b.date));
}
