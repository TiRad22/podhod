// ПОДХОД · стор: единый источник правды, write-through в IndexedDB, undo 5 с
import * as db from './db.js';
import { uuid, todayISO, round2, clamp } from './util.js';
import { DEFAULT_SCHEDULE, splitForDate, nextNum } from './scheduler.js';
import { seedExercises } from './seed.js';
import { best1pm, isPR, epley } from './analytics.js';
import { resolveExercise } from './parser.js';

export const DEFAULT_SETTINGS = {
  theme: 'dark',
  restSec: 90,
  autoRest: true,
  schedule: { ...DEFAULT_SCHEDULE },
  flags: { sleep: false, body: false, rpe: false },
  reminders: { enabled: false, time: '18:00', days: [2, 4, 6], quietFrom: '22:00', quietTo: '08:00', lastFired: null },
  historySortDesc: true,
};

export const state = {
  ready: false,
  workouts: [], exercises: [], entries: [], sets: [], sleep: [], body: [],
  settings: structuredClone(DEFAULT_SETTINGS),
  draftId: null,
  rest: null,          // { endsAt, totalSec } — таймер отдыха (сессия)
  undo: null,          // { token, label, until, stores:{...} }
};

const listeners = new Set();
export const subscribe = fn => (listeners.add(fn), () => listeners.delete(fn));
export const notify = () => listeners.forEach(fn => fn());

const persist = (store, v) => db.put(store, v);
const persistMany = (store, vs) => vs.length ? db.putMany(store, vs) : Promise.resolve();

export async function init() {
  const data = await db.loadAll();
  state.workouts = data.workouts;
  state.exercises = data.exercises;
  state.entries = data.entries;
  state.sets = data.sets;
  state.sleep = data.sleep;
  state.body = data.body;
  state.settings = { ...structuredClone(DEFAULT_SETTINGS), ...data.settings };
  state.settings.flags = { ...DEFAULT_SETTINGS.flags, ...(data.settings.flags ?? {}) };
  state.settings.schedule = { ...(data.settings.schedule ?? DEFAULT_SCHEDULE) };
  state.settings.reminders = { ...DEFAULT_SETTINGS.reminders, ...(data.settings.reminders ?? {}) };
  if (!state.exercises.length) {
    state.exercises = seedExercises();
    await db.putMany('exercises', state.exercises);
  }
  const draft = state.workouts.find(w => !w.finishedAt);
  state.draftId = draft?.id ?? null;
  state.ready = true;
  notify();
}

// ── Настройки ────────────────────────────────────────────────
export async function setSetting(key, value) {
  state.settings[key] = value;
  await persist('settings', { key, value });
  notify();
}
export const setFlag = (name, on) =>
  setSetting('flags', { ...state.settings.flags, [name]: on });

// ── Селекторы ────────────────────────────────────────────────
export const exerciseById = id => state.exercises.find(e => e.id === id);
export const workoutById = id => state.workouts.find(w => w.id === id);
export const draft = () => workoutById(state.draftId);
export const entriesOf = wid => state.entries.filter(e => e.workoutId === wid).sort((a, b) => a.order - b.order);
export const setsOf = eid => state.sets.filter(s => s.entryId === eid).sort((a, b) => a.order - b.order);
export const finishedWorkouts = () => state.workouts.filter(w => w.finishedAt);

export function lastSameSplit(split, excludeId = null) {
  return finishedWorkouts()
    .filter(w => w.split === split && w.id !== excludeId)
    .sort((a, b) => b.date.localeCompare(a.date) || b.num - a.num)[0] ?? null;
}

// Призраки прошлой такой же тренировки: группы минус уже записанные (вес+повторы)
export function ghostsFor(entry) {
  const w = workoutById(entry.workoutId);
  if (!w || w.finishedAt) return [];
  const prev = lastSameSplit(w.split, w.id);
  if (!prev) return [];
  const pe = entriesOf(prev.id).find(e => e.exerciseId === entry.exerciseId);
  if (!pe) return [];
  const real = setsOf(entry.id);
  return setsOf(pe.id).map(g => {
    const done = real.filter(r => r.weightKg === g.weightKg && r.reps === g.reps)
      .reduce((t, r) => t + r.count, 0);
    const left = g.count - done;
    return left > 0 ? { weightKg: g.weightKg, reps: g.reps, count: left } : null;
  }).filter(Boolean);
}

// ── Undo (FR-05): удаление сразу в БД, снапшот живёт 5 секунд ──
let undoTimer = null;
function registerUndo(label, stores) {
  if (undoTimer) clearTimeout(undoTimer);
  const token = uuid();
  state.undo = { token, label, until: Date.now() + 5000, stores };
  undoTimer = setTimeout(() => {
    if (state.undo?.token === token) { state.undo = null; notify(); }
  }, 5000);
  notify();
}
export async function undo() {
  const u = state.undo;
  if (!u || Date.now() > u.until + 300) return;
  clearTimeout(undoTimer);
  state.undo = null;
  for (const [store, rows] of Object.entries(u.stores)) {
    for (const row of rows) {
      await persist(store, row);
      const arr = state[store === 'sets' ? 'sets' : store];
      if (Array.isArray(arr) && !arr.some(x => x.id === row.id)) arr.push(row);
    }
  }
  if (u.stores.workouts?.some(w => !w.finishedAt)) state.draftId = u.stores.workouts.find(w => !w.finishedAt).id;
  notify();
}

async function cascadeDeleteWorkout(wid) {
  const w = workoutById(wid);
  const es = state.entries.filter(e => e.workoutId === wid);
  const eids = new Set(es.map(e => e.id));
  const gs = state.sets.filter(s => eids.has(s.entryId));
  await db.removeMany('sets', gs.map(g => g.id));
  await db.removeMany('entries', es.map(e => e.id));
  await db.remove('workouts', wid);
  state.sets = state.sets.filter(s => !eids.has(s.entryId));
  state.entries = state.entries.filter(e => e.workoutId !== wid);
  state.workouts = state.workouts.filter(x => x.id !== wid);
  if (state.draftId === wid) state.draftId = null;
  return { workouts: [w], entries: es, sets: gs };
}

// ── Тренировка (FR-01, FR-04, FR-07) ─────────────────────────
export async function startWorkout({ date = todayISO(), split, num } = {}) {
  if (state.draftId) return state.draftId;
  const s = split ?? splitForDate(date, state.settings.schedule) ?? 'chest';
  const w = {
    id: uuid(), num: num ?? nextNum(state.workouts), date, split: s,
    startedAt: Date.now(), finishedAt: null, durationMin: null, note: '', energy: null,
  };
  await persist('workouts', w);
  state.workouts.push(w);
  state.draftId = w.id;
  // Предзаполняем упражнениями прошлой такой же тренировки — призраки готовы к тапу
  const prev = lastSameSplit(s, w.id);
  if (prev) {
    const es = entriesOf(prev.id).map((e, i) => ({
      id: uuid(), workoutId: w.id, exerciseId: e.exerciseId, order: i,
    }));
    await persistMany('entries', es);
    state.entries.push(...es);
  }
  notify();
  return w.id;
}

export async function updateWorkout(wid, patch) {
  const w = workoutById(wid);
  if (!w) return;
  Object.assign(w, patch);
  await persist('workouts', w);
  notify();
}

export async function addExerciseToDraft(exerciseId) {
  const wid = state.draftId;
  if (!wid) return null;
  const es = entriesOf(wid);
  if (es.some(e => e.exerciseId === exerciseId)) return es.find(e => e.exerciseId === exerciseId).id;
  const entry = { id: uuid(), workoutId: wid, exerciseId, order: es.length };
  await persist('entries', entry);
  state.entries.push(entry);
  notify();
  return entry.id;
}

export async function moveEntry(entryId, dir) {
  const e = state.entries.find(x => x.id === entryId);
  if (!e) return;
  const list = entriesOf(e.workoutId);
  const i = list.findIndex(x => x.id === entryId);
  const j = i + dir;
  if (j < 0 || j >= list.length) return;
  const other = list[j];
  [e.order, other.order] = [other.order, e.order];
  await persistMany('entries', [e, other]);
  notify();
}

export async function removeEntry(entryId) {
  const e = state.entries.find(x => x.id === entryId);
  if (!e) return;
  const gs = state.sets.filter(s => s.entryId === entryId);
  await db.removeMany('sets', gs.map(g => g.id));
  await db.remove('entries', entryId);
  state.sets = state.sets.filter(s => s.entryId !== entryId);
  state.entries = state.entries.filter(x => x.id !== entryId);
  registerUndo(`«${exerciseById(e.exerciseId)?.name ?? 'Упражнение'}» удалено`, { entries: [e], sets: gs });
}

// ── Подходы (FR-03, FR-12) ───────────────────────────────────
function bestForPR(exerciseId, wid) {
  const hist = best1pm(exerciseId, state, wid);
  // учитываем и более ранние подходы этой же тренировки
  const eids = new Set(state.entries.filter(e => e.workoutId === wid && e.exerciseId === exerciseId).map(e => e.id));
  let cur = 0;
  for (const g of state.sets) if (eids.has(g.entryId)) cur = Math.max(cur, epley(g.weightKg, g.reps));
  return Math.max(hist, cur);
}

export async function addSet(entryId, { weightKg, reps, count = 1, rpe = null, failure = false }) {
  const e = state.entries.find(x => x.id === entryId);
  if (!e) return null;
  const w = round2(clamp(Number(weightKg) || 0, 0, 500));
  const r = clamp(Math.round(Number(reps) || 0), 1, 100);
  const c = clamp(Math.round(Number(count) || 1), 1, 50);
  const prevBest = bestForPR(e.exerciseId, e.workoutId);
  const pr = isPR(w, r, prevBest);
  const g = {
    id: uuid(), entryId, weightKg: w, reps: r, count: c, pr,
    order: setsOf(entryId).length,
    rpe: state.settings.flags.rpe ? rpe : null,
    failure: state.settings.flags.rpe ? !!failure : false,
  };
  await persist('sets', g);
  state.sets.push(g);
  notify();
  return { group: g, isPR: pr, oneRm: epley(w, r) };
}

export async function updateSet(groupId, patch) {
  const g = state.sets.find(x => x.id === groupId);
  if (!g) return;
  if ('weightKg' in patch) g.weightKg = round2(clamp(Number(patch.weightKg) || 0, 0, 500));
  if ('reps' in patch) g.reps = clamp(Math.round(Number(patch.reps) || 1), 1, 100);
  if ('count' in patch) g.count = clamp(Math.round(Number(patch.count) || 1), 1, 50);
  if ('rpe' in patch) g.rpe = patch.rpe;
  if ('failure' in patch) g.failure = !!patch.failure;
  const e = state.entries.find(x => x.id === g.entryId);
  if (e) {
    const others = { ...state, sets: state.sets.filter(s => s.id !== groupId) };
    g.pr = isPR(g.weightKg, g.reps, best1pm(e.exerciseId, others, e.workoutId));
  }
  await persist('sets', g);
  notify();
}

export async function removeSet(groupId) {
  const g = state.sets.find(x => x.id === groupId);
  if (!g) return;
  await db.remove('sets', groupId);
  state.sets = state.sets.filter(x => x.id !== groupId);
  registerUndo('Подход удалён', { sets: [g] });
}

export async function repeatAll(entryId) {
  const ghosts = ghostsFor(state.entries.find(e => e.id === entryId));
  let anyPR = false;
  for (const gh of ghosts) {
    const res = await addSet(entryId, gh);
    anyPR = anyPR || res?.isPR;
  }
  return { added: ghosts.length, anyPR };
}

// ── Финиш (FR-08) ────────────────────────────────────────────
export async function finishDraft({ energy = null, note = '' } = {}) {
  const w = draft();
  if (!w) return { empty: true };
  const es = entriesOf(w.id);
  const hasSets = es.some(e => setsOf(e.id).length);
  if (!hasSets) return { empty: true };
  // пустые упражнения (одни призраки) не сохраняем
  const emptyEntries = es.filter(e => !setsOf(e.id).length);
  if (emptyEntries.length) {
    await db.removeMany('entries', emptyEntries.map(e => e.id));
    state.entries = state.entries.filter(e => !emptyEntries.some(x => x.id === e.id));
  }
  w.finishedAt = Date.now();
  w.durationMin = Math.max(1, Math.round((w.finishedAt - w.startedAt) / 60000));
  w.energy = energy;
  w.note = note?.trim() || '';
  await persist('workouts', w);
  state.draftId = null;
  state.rest = null;
  notify();
  return { empty: false, workout: w };
}

export async function deleteWorkout(wid) {
  const snap = await cascadeDeleteWorkout(wid);
  registerUndo(`Тренировка №${snap.workouts[0].num} удалена`, snap);
}
export const discardDraft = () => state.draftId && deleteWorkout(state.draftId);

// ── Таймер отдыха (FR-06) ────────────────────────────────────
export function startRest(sec = state.settings.restSec) {
  state.rest = { endsAt: Date.now() + sec * 1000, totalSec: sec };
  notify();
}
export function addRest(sec = 15) {
  if (!state.rest) return;
  state.rest.endsAt += sec * 1000;
  state.rest.totalSec += sec;
  notify();
}
export function skipRest() { state.rest = null; notify(); }

// ── Каталог (FR-09) ──────────────────────────────────────────
export async function addExercise({ name, group, equipment = null, aliases = [] }) {
  const e = { id: uuid(), name: name.trim(), group, equipment, aliases, custom: true };
  await persist('exercises', e);
  state.exercises.push(e);
  notify();
  return e;
}
export async function updateExercise(id, patch) {
  const e = exerciseById(id);
  if (!e) return;
  Object.assign(e, patch);
  await persist('exercises', e);
  notify();
}
export const exerciseUsed = id => state.entries.some(e => e.exerciseId === id);
export async function deleteExercise(id) {
  if (exerciseUsed(id)) return false;
  await db.remove('exercises', id);
  state.exercises = state.exercises.filter(e => e.id !== id);
  notify();
  return true;
}

// ── Сон и тело (FR-18, FR-19) ────────────────────────────────
export async function upsertSleep({ date, hours, quality }) {
  const ex = state.sleep.find(s => s.date === date);
  const rec = { id: ex?.id ?? uuid(), date, hours: round2(hours), quality: clamp(Math.round(quality), 1, 5) };
  await persist('sleep', rec);
  if (ex) Object.assign(ex, rec); else state.sleep.push(rec);
  notify();
}
export async function deleteSleep(id) {
  await db.remove('sleep', id);
  state.sleep = state.sleep.filter(s => s.id !== id);
  notify();
}
export async function upsertBody(rec) {
  const ex = state.body.find(b => b.date === rec.date);
  const r = { id: ex?.id ?? uuid(), ...rec };
  await persist('body', r);
  if (ex) Object.assign(ex, r); else state.body.push(r);
  notify();
}
export async function deleteBody(id) {
  await db.remove('body', id);
  state.body = state.body.filter(b => b.id !== id);
  notify();
}

// ── Экспорт / импорт JSON (FR-23) ────────────────────────────
export function exportJSON() {
  return {
    app: 'podhod', version: 1, exportedAt: new Date().toISOString(),
    data: {
      workouts: state.workouts, exercises: state.exercises, entries: state.entries,
      sets: state.sets, sleep: state.sleep, body: state.body,
    },
    settings: state.settings,
  };
}
export async function importJSON(obj) {
  if (obj?.app !== 'podhod' || obj?.version !== 1 || !obj?.data)
    throw new Error('Это не бэкап ПОДХОД v1');
  const d = obj.data;
  for (const k of ['workouts', 'exercises', 'entries', 'sets'])
    if (!Array.isArray(d[k])) throw new Error(`Повреждён файл: нет таблицы ${k}`);
  await db.replaceAll({ sleep: [], body: [], ...d }, obj.settings ?? {});
  state.rest = null; state.undo = null;
  await init();
}

// ── Импорт блокнота (FR-17) ──────────────────────────────────
// block: {num, date, split, entries:[{name, group, exerciseId?, isNew, sets}], replace?}
export async function importNotebookBlock(block, { replace = false } = {}) {
  const existing = block.num != null ? state.workouts.find(w => w.num === block.num) : null;
  if (existing && !replace) return { skipped: true };
  if (existing && replace) await cascadeDeleteWorkout(existing.id);

  const date = block.date || todayISO();
  const split = block.split || splitForDate(date, state.settings.schedule) || 'chest';
  const num = block.num ?? nextNum(state.workouts);
  const w = {
    id: uuid(), num, date, split,
    startedAt: null, finishedAt: new Date(date + 'T12:00:00').getTime(),
    durationMin: null, note: block.note ?? '', energy: null,
  };
  await persist('workouts', w);
  state.workouts.push(w);

  const newEntries = [], newSets = [];
  let order = 0;
  for (const en of block.entries) {
    let ex = en.exerciseId ? exerciseById(en.exerciseId) : resolveExercise(en.name, state.exercises);
    if (!ex) ex = await addExercise({ name: en.name, group: en.group || 'Грудь' });
    const entry = { id: uuid(), workoutId: w.id, exerciseId: ex.id, order: order++ };
    newEntries.push(entry);
    state.entries.push(entry); // сразу, чтобы PR видел ранние подходы этого импорта
    let sOrder = 0;
    for (const s of en.sets) {
      const prevBest = bestForPR(ex.id, w.id);
      const g = {
        id: uuid(), entryId: entry.id, weightKg: s.weightKg, reps: s.reps, count: s.count,
        pr: isPR(s.weightKg, s.reps, prevBest), order: sOrder++, rpe: null, failure: false,
      };
      newSets.push(g);
      state.sets.push(g); // чтобы следующие подходы видели предыдущие
    }
  }
  await persistMany('entries', newEntries);
  await persistMany('sets', newSets);
  notify();
  return { skipped: false, workout: w };
}

// ── Полный сброс ─────────────────────────────────────────────
export async function wipeAll() {
  await db.clearAll();
  state.workouts = []; state.entries = []; state.sets = []; state.sleep = []; state.body = [];
  state.exercises = seedExercises();
  await db.putMany('exercises', state.exercises);
  state.settings = structuredClone(DEFAULT_SETTINGS);
  state.draftId = null; state.rest = null; state.undo = null;
  notify();
}
