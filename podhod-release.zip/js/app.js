// ПОДХОД · оболочка: роутинг, рендер, таймеры, undo-тост, PWA, напоминания
import * as store from './core/store.js';
import { state } from './core/store.js';
import { fmtElapsed, fmtClock, todayISO, fmtInt } from './core/util.js';
import { splitForDate, nextNum, SPLITS } from './core/scheduler.js';
import { navigate, parseRoute } from './ui/router.js';
import { icon, closeModal, modalActions, modalInputs, isModalOpen } from './ui/components.js';
import * as today from './ui/today.js';
import * as journal from './ui/journal.js';
import * as historyScreen from './ui/history.js';
import * as card from './ui/card.js';
import * as analytics from './ui/analytics.js';
import * as catalog from './ui/catalog.js';
import * as settings from './ui/settings.js';
import * as more from './ui/more.js';
import * as bodyScreen from './ui/body.js';
import * as sleepScreen from './ui/sleep.js';
import * as importScreen from './ui/import.js';

const ROUTES = {
  today, journal, history: historyScreen, card, analytics, catalog, settings, more,
  body: bodyScreen, sleep: sleepScreen, import: importScreen,
};
const NAV = [
  ['today', 'Сегодня', 'home'],
  ['history', 'История', 'history'],
  ['analytics', 'Аналитика', 'chart'],
  ['more', 'Ещё', 'dots'],
];

let current = { name: null, param: null };
let screenMod = today;
let deferredInstall = null;
let lastUndoToken = null;
let restDoneShown = false;

export const getInstallPrompt = () => deferredInstall;
export async function promptInstall() {
  if (!deferredInstall) return false;
  deferredInstall.prompt();
  const { outcome } = await deferredInstall.userChoice;
  deferredInstall = null;
  return outcome === 'accepted';
}

/* ── Рендер ── */
function render() {
  if (!state.ready) return;
  const route = parseRoute();
  const mod = ROUTES[route.name] ?? today;
  const sameRoute = current.name === route.name && current.param === route.param;
  const y = window.scrollY;
  screenMod = mod;
  current = route;
  document.getElementById('screen').innerHTML = mod.render(route.param);
  mod.mount?.(route.param);
  renderNav();
  renderRestDock();
  renderToast();
  applyTheme();
  if (sameRoute) window.scrollTo(0, y); else window.scrollTo(0, 0);
  tick();
}

function renderNav() {
  const nav = document.getElementById('bottom-nav');
  const active = ['journal'].includes(current.name) ? 'today'
    : ['card'].includes(current.name) ? 'history'
    : ['catalog', 'settings', 'body', 'sleep', 'import'].includes(current.name) ? 'more'
    : current.name;
  nav.innerHTML = NAV.map(([name, label, ic]) =>
    `<button data-action="nav" data-to="${name}" class="${active === name ? 'active' : ''}" aria-label="${label}">
      ${name === 'today' && state.draftId ? '<span class="nav-dot"></span>' : ''}${icon(ic)}<span>${label}</span>
    </button>`).join('');
}

function applyTheme() {
  document.documentElement.dataset.theme = state.settings.theme;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', state.settings.theme === 'light' ? '#F2EFE6' : '#12151A');
}

/* ── Таймер отдыха (док живёт над навигацией на всех экранах) ── */
const RING_C = 2 * Math.PI * 24;
function renderRestDock() {
  const dock = document.getElementById('rest-dock');
  if (!state.rest) { dock.innerHTML = ''; dock.hidden = true; restDoneShown = false; return; }
  dock.hidden = false;
  dock.innerHTML = `
    <div class="ring-wrap">
      <svg width="56" height="56" viewBox="0 0 56 56">
        <circle cx="28" cy="28" r="24" fill="none" stroke="var(--surface3)" stroke-width="5"/>
        <circle id="rest-ring" cx="28" cy="28" r="24" fill="none" stroke="var(--primary)" stroke-width="5"
          stroke-linecap="round" stroke-dasharray="${RING_C}" stroke-dashoffset="0"/>
      </svg>
      <span class="ring-time" id="rest-time"></span>
    </div>
    <span class="rest-label" id="rest-label">Отдых</span>
    <button class="btn small-btn" data-action="rest-add" aria-label="Плюс 15 секунд">+15 с</button>
    <button class="icon-btn plain" data-action="rest-skip" aria-label="Пропустить отдых">${icon('x')}</button>`;
  tick();
}

function renderToast() {
  const t = document.getElementById('toast');
  const u = state.undo;
  if (!u) { t.innerHTML = ''; t.hidden = true; lastUndoToken = null; return; }
  if (lastUndoToken === u.token) return;
  lastUndoToken = u.token;
  t.hidden = false;
  t.innerHTML = `<span class="toast-label">${u.label}</span>
    <button class="undo-btn" data-action="undo">Вернуть</button><span class="toast-bar"></span>`;
}

/* ── Глобальный тик 1 с: живое время тренировки и кольцо отдыха ── */
function tick() {
  const now = Date.now();
  document.querySelectorAll('[data-elapsed-start]').forEach(el => {
    el.textContent = fmtElapsed(now - Number(el.dataset.elapsedStart));
  });
  if (state.rest) {
    const left = (state.rest.endsAt - now) / 1000;
    const ring = document.getElementById('rest-ring');
    const time = document.getElementById('rest-time');
    const label = document.getElementById('rest-label');
    const dock = document.getElementById('rest-dock');
    if (ring) {
      const frac = Math.max(0, Math.min(1, left / state.rest.totalSec));
      ring.style.strokeDashoffset = String(RING_C * (1 - frac));
      ring.style.stroke = left <= 0 ? 'var(--success)' : left <= 10 ? 'var(--legs)' : 'var(--primary)';
    }
    if (time) time.textContent = left > 0 ? fmtClock(left) : '0:00';
    if (left <= 0 && !restDoneShown) {
      restDoneShown = true;
      dock?.classList.add('done');
      if (label) label.textContent = 'Пора! 💪';
    } else if (left > 0) {
      restDoneShown = false;
      dock?.classList.remove('done');
      if (label) label.textContent = 'Отдых';
    }
  }
}

/* ── Диспетчер событий (делегирование) ── */
const GLOBAL_ACTIONS = {
  nav: el => navigate(el.dataset.to),
  'open-workout': el => { closeModal(); navigate('card', el.dataset.id); },
  'modal-close': () => closeModal(),
  undo: () => store.undo(),
  'rest-add': () => store.addRest(15),
  'rest-skip': () => store.skipRest(),
  'theme-toggle': () => store.setSetting('theme', state.settings.theme === 'dark' ? 'light' : 'dark'),
  'install-app': async () => {
    const ok = await promptInstall();
    if (!ok) alert('Если окно не появилось: меню браузера → «Установить приложение» / «На экран Домой».');
  },
};

function findAction(el) {
  const a = el.closest('[data-action]');
  return a;
}
document.addEventListener('click', async e => {
  const el = findAction(e.target);
  if (!el) return;
  const name = el.dataset.action;
  const inModal = !!el.closest('#modal-root');
  const handler = (inModal && modalActions()?.[name]) || screenMod.actions?.[name] || GLOBAL_ACTIONS[name];
  if (handler) { e.preventDefault(); await handler(el, e); }
});
function inputDispatch(e) {
  const el = e.target.closest('[data-input]');
  if (!el) return;
  const name = el.dataset.input;
  const inModal = !!el.closest('#modal-root');
  const handler = (inModal && modalInputs()?.[name]) || screenMod.inputs?.[name];
  handler?.(el, e);
}
document.addEventListener('input', inputDispatch);
document.addEventListener('change', e => {
  const el = e.target.closest('[data-change]');
  if (!el) return;
  const inModal = !!el.closest('#modal-root');
  const handler = (inModal && modalActions()?.[el.dataset.change]) || screenMod.actions?.[el.dataset.change];
  handler?.(el, e);
});

/* ── Напоминания (FR-21): локально, пока приложение открыто ── */
async function checkReminder() {
  const r = state.settings.reminders;
  if (!r?.enabled || !('Notification' in window) || Notification.permission !== 'granted') return;
  const now = new Date();
  const today = todayISO();
  if (!r.days.includes(now.getDay()) || r.lastFired === today) return;
  const [hh, mm] = r.time.split(':').map(Number);
  if (now.getHours() * 60 + now.getMinutes() < hh * 60 + mm) return;
  const mins = now.getHours() * 60 + now.getMinutes();
  const [qf, qt] = [r.quietFrom, r.quietTo].map(t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; });
  const quiet = qf > qt ? (mins >= qf || mins < qt) : (mins >= qf && mins < qt);
  if (quiet) return;
  const split = splitForDate(today, state.settings.schedule);
  const body = split
    ? `Сегодня по плану: ${SPLITS[split].label}. Тренировка №${nextNum(state.workouts)} ждёт 💪`
    : 'Запланированная тренировка ждёт 💪';
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg?.showNotification) await reg.showNotification('ПОДХОД', { body, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: 'podhod-reminder' });
    else new Notification('ПОДХОД', { body, icon: 'icons/icon-192.png' });
  } catch { /* noop */ }
  store.setSetting('reminders', { ...r, lastFired: today });
}

/* ── Загрузка ── */
async function boot() {
  applyTheme();
  store.subscribe(render);
  window.addEventListener('hashchange', render);
  await store.init();
  if (!location.hash) navigate('today');
  render();
  setInterval(tick, 1000);
  setInterval(checkReminder, 30000);

  if ('serviceWorker' in navigator) {
    try {
      const hadController = !!navigator.serviceWorker.controller;
      const reg = await navigator.serviceWorker.register('sw.js');
      reg.addEventListener('updatefound', () => {
        const nw = reg.installing;
        nw?.addEventListener('statechange', () => {
          if (nw.state === 'installed' && navigator.serviceWorker.controller)
            nw.postMessage('skip-waiting');
        });
      });
      let reloaded = false;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        // перезагружаем только при обновлении уже установленной оболочки, не при первой установке
        if (hadController && !reloaded) { reloaded = true; location.reload(); }
      });
    } catch { /* офлайн-режим без SW всё равно работает из кэша браузера */ }
  }
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; render(); });
  window.addEventListener('appinstalled', () => { deferredInstall = null; render(); });
  const updOnline = () => document.querySelectorAll('.offline-dot').forEach(el => {
    el.classList.toggle('off', !navigator.onLine);
    el.textContent = navigator.onLine ? 'онлайн' : 'офлайн · всё работает';
  });
  window.addEventListener('online', updOnline);
  window.addEventListener('offline', updOnline);
}

boot();
