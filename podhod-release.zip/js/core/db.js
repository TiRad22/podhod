// ПОДХОД · IndexedDB-хранилище (NFR: офлайн, автосохранение, 5 лет < 5 МБ)
const DB_NAME = 'podhod';
const DB_VERSION = 1;
export const STORES = ['workouts', 'exercises', 'entries', 'sets', 'sleep', 'body', 'settings'];

let dbp = null;
export function open() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      const mk = (name, idx = []) => {
        if (!db.objectStoreNames.contains(name)) {
          const s = db.createObjectStore(name, { keyPath: name === 'settings' ? 'key' : 'id' });
          for (const [n, key, uniq] of idx) s.createIndex(n, key, { unique: !!uniq });
        }
      };
      mk('workouts', [['num', 'num'], ['date', 'date']]);
      mk('exercises');
      mk('entries', [['workoutId', 'workoutId']]);
      mk('sets', [['entryId', 'entryId']]);
      mk('sleep', [['date', 'date', true]]);
      mk('body', [['date', 'date', true]]);
      mk('settings');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbp;
}

const tx = async (stores, mode, fn) => {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(stores, mode);
    let out;
    t.oncomplete = () => resolve(out);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
    out = fn(t);
  });
};

const all = store => new Promise((res, rej) => {
  const r = store.getAll();
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
});

export async function loadAll() {
  const db = await open();
  const t = db.transaction(STORES, 'readonly');
  const [workouts, exercises, entries, sets, sleep, body, settingsRows] =
    await Promise.all(STORES.map(s => all(t.objectStore(s))));
  const settings = {};
  for (const row of settingsRows) settings[row.key] = row.value;
  return { workouts, exercises, entries, sets, sleep, body, settings };
}

export const put = (store, value) =>
  tx([store], 'readwrite', t => t.objectStore(store).put(value));

export const putMany = (store, values) =>
  tx([store], 'readwrite', t => { const s = t.objectStore(store); values.forEach(v => s.put(v)); });

export const remove = (store, id) =>
  tx([store], 'readwrite', t => t.objectStore(store).delete(id));

export const removeMany = (store, ids) =>
  tx([store], 'readwrite', t => { const s = t.objectStore(store); ids.forEach(id => s.delete(id)); });

// Атомарная замена всего (импорт JSON) — FR-23
export async function replaceAll(data, settings) {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES, 'readwrite');
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
    for (const s of STORES) t.objectStore(s).clear();
    for (const s of ['workouts', 'exercises', 'entries', 'sets', 'sleep', 'body'])
      (data[s] ?? []).forEach(v => t.objectStore(s).put(v));
    for (const [key, value] of Object.entries(settings ?? {}))
      t.objectStore('settings').put({ key, value });
  });
}

export async function clearAll() {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORES, 'readwrite');
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
    STORES.forEach(s => t.objectStore(s).clear());
  });
}
