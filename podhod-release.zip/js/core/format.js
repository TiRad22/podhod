// ПОДХОД · текст блокнота 1-в-1 (FR-11). Обратим к parser.js.
import { fmtKg } from './util.js';

// «52 кг на 9», «39 кг на 11 2», «Свой вес на 12 3»
export const setNotation = g => {
  const base = g.weightKg > 0 ? `${fmtKg(g.weightKg)} кг на ${g.reps}` : `Свой вес на ${g.reps}`;
  return g.count > 1 ? `${base} ${g.count}` : base;
};

// Первая группа — на строке с названием, остальные — отдельными строками
export const exerciseLines = (name, groups) => {
  if (!groups.length) return [name];
  return [`${name} ${setNotation(groups[0])}`, ...groups.slice(1).map(setNotation)];
};

export function workoutText(workout, entries, exercises, sets) {
  const byId = new Map(exercises.map(e => [e.id, e]));
  const lines = [`Тренировка ${workout.num}`];
  const es = entries.filter(e => e.workoutId === workout.id).sort((a, b) => a.order - b.order);
  for (const e of es) {
    const gs = sets.filter(s => s.entryId === e.id).sort((a, b) => a.order - b.order);
    lines.push(...exerciseLines(byId.get(e.exerciseId)?.name ?? 'Упражнение', gs));
  }
  if (workout.note) lines.push(`Заметка: ${workout.note}`);
  return lines.join('\n');
}
