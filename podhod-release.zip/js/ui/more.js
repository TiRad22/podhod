// ПОДХОД · экран «Ещё»: модули и сервис
import { state, exportJSON } from '../core/store.js';
import { todayISO } from '../core/util.js';
import { icon } from './components.js';

function download(filename, text) {
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
export const doExport = () =>
  download(`podhod-backup-${todayISO()}.json`, JSON.stringify(exportJSON(), null, 2));

export function render() {
  const f = state.settings.flags;
  const row = (to, ic, title, sub, color = 'var(--text)') => `
    <div class="link-row" data-action="nav" data-to="${to}">
      <span class="lr-icon" style="color:${color}">${icon(ic)}</span>
      <div class="grow"><div class="title">${title}</div><div class="sub">${sub}</div></div>
      ${icon('chevR', 'chev')}
    </div>`;
  return `
  <div class="page-head"><h1>Ещё</h1></div>
  <div class="card" style="padding:4px 16px">
    ${row('catalog', 'book', 'Каталог упражнений', `${state.exercises.length} упражнений · алиасы блокнота`)}
    ${row('import', 'note', 'Импорт из заметок', 'вставил текст — получил тренировку')}
    ${f.body ? row('body', 'scale', 'Вес и замеры', 'вес тела рядом с тоннажом', 'var(--body)') : ''}
    ${f.sleep ? row('sleep', 'bed', 'Сон и восстановление', 'часы, качество, связь с тоннажом', 'var(--sleep)') : ''}
    ${row('settings', 'gear', 'Настройки', 'тема, отдых, расписание, модули, бэкап')}
  </div>
  <div class="card" style="padding:4px 16px">
    <div class="link-row" data-action="export-now">
      <span class="lr-icon" style="color:var(--success)">${icon('download')}</span>
      <div class="grow"><div class="title">Экспорт бэкапа</div><div class="sub">один JSON-файл со всеми данными</div></div>
    </div>
  </div>
  <p class="muted tiny" style="text-align:center">ПОДХОД v1.0 · без аккаунта, сервера и телеметрии<br>все данные живут только на этом устройстве</p>`;
}

export const actions = { 'export-now': doExport };
