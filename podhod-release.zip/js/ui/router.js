// ПОДХОД · хэш-роутер (кнопка «назад» работает как ожидается)
export function parseRoute() {
  const h = location.hash.replace(/^#\/?/, '');
  const [name, param] = h.split('/');
  return { name: name || 'today', param: param ? decodeURIComponent(param) : null };
}
export function navigate(name, param = null) {
  const h = '#/' + name + (param ? '/' + encodeURIComponent(param) : '');
  if (location.hash === h) return;
  location.hash = h;
}
export const back = () => history.back();
