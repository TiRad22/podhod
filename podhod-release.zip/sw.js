// ПОДХОД · Service Worker (сгенерирован tools/make-sw.mjs, не править вручную)
// Офлайн-first: вся оболочка в precache, обязательных внешних запросов — ноль.
const VERSION = 'podhod-930c820f97';
const PRECACHE = ['./', 'fonts/fonts.css', 'fonts/inter-var-cyrillic.woff2', 'fonts/inter-var-latin.woff2', 'fonts/jbmono-var-cyrillic.woff2', 'fonts/jbmono-var-latin.woff2', 'fonts/russo-400-cyrillic.woff2', 'fonts/russo-400-latin.woff2', 'icons/apple-touch-icon.png', 'icons/favicon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-512.png', 'index.html', 'js/app.js', 'js/core/analytics.js', 'js/core/db.js', 'js/core/format.js', 'js/core/parser.js', 'js/core/scheduler.js', 'js/core/seed.js', 'js/core/store.js', 'js/core/util.js', 'js/ui/analytics.js', 'js/ui/body.js', 'js/ui/card.js', 'js/ui/catalog.js', 'js/ui/components.js', 'js/ui/history.js', 'js/ui/import.js', 'js/ui/journal.js', 'js/ui/more.js', 'js/ui/router.js', 'js/ui/settings.js', 'js/ui/sleep.js', 'js/ui/today.js', 'manifest.webmanifest', 'styles.css'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('message', e => { if (e.data === 'skip-waiting') self.skipWaiting(); });

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== self.location.origin) return;
  // навигация: сеть → кэш (чтобы обновление подхватывалось), ассеты: кэш → сеть
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then(r => {
      const copy = r.clone();
      caches.open(VERSION).then(c => c.put('./', copy));
      return r;
    }).catch(() => caches.match('./')));
    return;
  }
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request).then(r => {
    if (r.ok) { const copy = r.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)); }
    return r;
  })));
});
