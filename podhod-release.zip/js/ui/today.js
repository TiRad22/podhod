// ПОДХОД · экран «Сегодня» (FR-01, FR-07, виджеты сна/тела)
import { state, draft, entriesOf, setsOf, startWorkout, lastSameSplit } from '../core/store.js';
import { todayISO, fmtDate, fmtDateFull, fromISO, addDaysISO, fmtInt, fmtElapsed, WEEKDAYS } from '../core/util.js';
import { splitForDate, nextNum, SPLITS, SPLIT_KEYS, streak } from '../core/scheduler.js';
import { weeklySummary, workoutStats } from '../core/analytics.js';
import { navigate } from './router.js';
import { icon, plateNum, splitTag, empty, openModal, closeModal } from './components.js';

export function render() {
  const today = todayISO();
  const d = draft();
  const planned = splitForDate(today, state.settings.schedule);
  const num = nextNum(state.workouts);
  const sum = weeklySummary(state, today, state.settings.schedule);
  const last = state.workouts.filter(w => w.finishedAt).sort((a, b) => b.date.localeCompare(a.date) || b.num - a.num)[0];

  const monday = addDaysISO(today, -((fromISO(today).getDay() + 6) % 7));
  const doneDates = new Set(state.workouts.filter(w => w.finishedAt).map(w => w.date));
  const week = Array.from({ length: 7 }, (_, i) => {
    const iso = addDaysISO(monday, i);
    const sp = splitForDate(iso, state.settings.schedule);
    const done = doneDates.has(iso);
    const style = sp ? `--pc:${SPLITS[sp].color}` : '';
    return `<div class="week-day${iso === today ? ' today' : ''}" style="${style}">
      <div class="wd-dot${sp ? ' planned' : ''}${done ? ' done' : ''}">${done ? '✓' : sp ? SPLITS[sp].label[0] : '·'}</div>${WEEKDAYS[(i + 1) % 7]}</div>`;
  }).join('');

  const sleepWidget = state.settings.flags.sleep ? (() => {
    const s = state.sleep.find(x => x.date === today) ?? state.sleep.find(x => x.date === addDaysISO(today, -1));
    return `<div class="card tap" data-action="nav" data-to="sleep">
      <div class="card-head">${icon('bed')}<h3>Сон</h3><span class="spacer"></span><span class="muted small">${s ? (s.date === today ? 'прошлой ночью' : 'вчера') : ''}</span></div>
      ${s ? `<div class="display" style="font-size:1.3rem;color:${s.hours < 6 ? 'var(--danger)' : 'var(--sleep)'}">${String(s.hours).replace('.', ',')} ч ${s.hours < 6 ? '⚠ недосып' : ''}</div>
        <div class="muted small">качество ${s.quality}/5 · тап, чтобы изменить</div>`
      : `<div class="muted small">Записать прошлую ночь →</div>`}
    </div>`;
  })() : '';

  const bodyWidget = state.settings.flags.body ? (() => {
    const b = [...state.body].sort((a, b2) => b2.date.localeCompare(a.date))[0];
    return `<div class="card tap" data-action="nav" data-to="body">
      <div class="card-head">${icon('scale')}<h3>Вес тела</h3><span class="spacer"></span></div>
      ${b ? `<div class="display" style="font-size:1.3rem;color:var(--body)">${String(b.weightKg).replace('.', ',')} кг</div><div class="muted small">${fmtDate(b.date)} · тап, чтобы записать</div>`
      : `<div class="muted small">Первый замер за 15 секунд →</div>`}
    </div>`;
  })() : '';

  return `
  <div class="page-head">
    <div><h1 class="display">ПОДХОД</h1><div class="head-sub">${fmtDateFull(today)}</div></div>
    <span class="spacer"></span>
    <span class="offline-dot${navigator.onLine ? '' : ' off'}">${navigator.onLine ? 'онлайн' : 'офлайн · всё работает'}</span>
    <button class="icon-btn plain" data-action="theme-toggle" aria-label="Сменить тему">${icon(state.settings.theme === 'dark' ? 'sun' : 'moon')}</button>
  </div>

  ${d ? `
  <div class="card" style="border-color:var(--success)">
    <div class="card-head">${plateNum(d.num, d.split)}
      <div><h3>Тренировка №${d.num} идёт</h3><div class="muted small">${SPLITS[d.split].label} · <span class="mono" data-elapsed-start="${d.startedAt}">${fmtElapsed(Date.now() - d.startedAt)}</span> · подходов: ${entriesOf(d.id).reduce((t, e) => t + setsOf(e.id).reduce((a, g) => a + g.count, 0), 0)}</div></div>
    </div>
    <button class="btn primary big" data-action="nav" data-to="journal">${icon('play')} Продолжить</button>
  </div>` : `
  <div class="card">
    ${planned
      ? `<div class="card-head">${plateNum(num, planned)}<div><h3>Сегодня по плану: ${SPLITS[planned].label}</h3><div class="muted small">Тренировка №${num} · ${fmtDate(today)}</div></div></div>
         <button class="btn primary big" data-action="start-planned">${icon('play')} Начать тренировку</button>
         <div class="btn-row" style="margin-top:10px"><button class="btn ghost small-btn" data-action="start-modal">Другой день / сплит</button></div>`
      : `<div class="card-head"><span style="font-size:1.6rem">😌</span><div><h3>Сегодня отдых</h3><div class="muted small">По плану ближайшая: ${nextPlanText()}</div></div></div>
         <button class="btn big" data-action="start-modal">${icon('plus')} Тренировка вне плана</button>`}
  </div>`}

  <div class="card">
    <div class="card-head"><h3>Неделя</h3><span class="spacer"></span><span class="muted small">серия 🔥 ${sum.streak}</span></div>
    <div class="week-strip">${week}</div>
  </div>

  <div class="tiles">
    <div class="tile"><div class="tile-l">Тоннаж за 7 дней</div><div class="tile-v">${fmtInt(sum.tonnage)}<span class="muted" style="font-size:.9rem"> кг</span>${deltaBadge(sum.delta)}</div></div>
    <div class="tile"><div class="tile-l">Подходы за 7 дней</div><div class="tile-v">${sum.sets}</div></div>
  </div>

  ${sleepWidget}${bodyWidget}

  ${last ? `
  <div class="section-title">Последняя тренировка</div>
  <div class="card tap" data-action="open-workout" data-id="${last.id}">
    <div class="card-head">${plateNum(last.num, last.split)}
      <div class="grow"><h3>№${last.num} · ${SPLITS[last.split].label}</h3><div class="muted small">${fmtDate(last.date)}</div></div>
      ${icon('chevR', 'chev')}
    </div>
    ${statLine(last.id)}
  </div>` : empty('🏋️', 'Первая тренировка ждёт', 'Начните по плану — номер и сплит подставятся сами')}
  `;
}

function nextPlanText() {
  for (let i = 1; i <= 7; i++) {
    const iso = addDaysISO(todayISO(), i);
    const sp = splitForDate(iso, state.settings.schedule);
    if (sp) return `${fmtDate(iso)} — ${SPLITS[sp].label}`;
  }
  return 'расписание пустое';
}

export function statLine(wid) {
  const s = workoutStats(wid, state.entries, state.sets);
  const w = state.workouts.find(x => x.id === wid);
  return `<div class="stat-line"><span><b>${s.sets}</b> подх.</span><span><b>${fmtInt(s.tonnage)}</b> кг</span><span><b>${w?.durationMin ? w.durationMin + ' мин' : '—'}</b></span>${s.prs ? `<span style="color:var(--primary)">★ ${s.prs} PR</span>` : ''}</div>`;
}

export const deltaBadge = d =>
  d == null ? '' : `<span class="delta ${d > 0 ? 'up' : d < 0 ? 'down' : 'flat'}">${d > 0 ? '+' : ''}${d}%</span>`;

export const actions = {
  'start-planned': async () => {
    await startWorkout({});
    navigate('journal');
  },
  'start-modal': () => {
    const today = todayISO();
    const planned = splitForDate(today, state.settings.schedule);
    openModal({
      html: `
      <div class="modal-title">Новая тренировка<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
      <div class="modal-sub">Номер продолжится автоматически, всё можно поменять</div>
      <div class="field-label">Дата</div>
      <input type="date" id="start-date" value="${today}">
      <div class="field-label">Сплит</div>
      <select id="start-split">${SPLIT_KEYS.map(k => `<option value="${k}" ${k === (planned ?? 'chest') ? 'selected' : ''}>${SPLITS[k].label}</option>`).join('')}</select>
      <div class="field-label">Номер</div>
      <input type="number" id="start-num" inputmode="numeric" value="${nextNum(state.workouts)}" min="1">
      <div style="height:16px"></div>
      <button class="btn primary big" data-action="do-start">${icon('play')} Начать</button>`,
      actions: {
        'do-start': async () => {
          const date = document.getElementById('start-date').value || today;
          const split = document.getElementById('start-split').value;
          const num = Math.max(1, parseInt(document.getElementById('start-num').value, 10) || nextNum(state.workouts));
          closeModal();
          await startWorkout({ date, split, num });
          navigate('journal');
        },
      },
    });
  },
};
