// ПОДХОД · каталог упражнений: поиск, фильтр, свои упражнения, алиасы (FR-09)
import { state, addExercise, updateExercise, deleteExercise, exerciseUsed, notify } from '../core/store.js';
import { escapeHtml, normName } from '../core/util.js';
import { GROUPS, EQUIPMENT } from '../core/seed.js';
import { icon, empty, openModal, closeModal } from './components.js';

let q = '';
let group = 'Все';

function list() {
  const qq = normName(q);
  return state.exercises
    .filter(e => group === 'Все' || e.group === group)
    .filter(e => !qq || normName(e.name).includes(qq) || (e.aliases ?? []).some(a => normName(a).includes(qq)))
    .sort((a, b) => a.group.localeCompare(b.group, 'ru') || a.name.localeCompare(b.name, 'ru'));
}

function listHTML() {
  const es = list();
  if (!es.length) return empty('📚', 'Ничего не нашлось', 'Создайте своё упражнение кнопкой ниже');
  return `<div class="card">${es.map(e => `
    <div class="list-row" data-action="edit-ex" data-id="${e.id}" style="cursor:pointer">
      <div class="grow"><div class="title">${escapeHtml(e.name)}${e.custom ? ' <span class="muted tiny">· своё</span>' : ''}</div>
      <div class="sub">${e.equipment ?? ''}${e.aliases?.length ? ` · алиасы: ${escapeHtml(e.aliases.join(', '))}` : ''}</div></div>
      <span class="group-tag">${e.group}</span>
    </div>`).join('')}</div>`;
}

export function render() {
  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="nav" data-to="more" aria-label="Назад">${icon('chevL')}</button>
    <h1>Каталог</h1><span class="spacer"></span><span class="muted small">${state.exercises.length}</span>
  </div>
  <div class="search-wrap">${icon('search')}<input data-input="q" placeholder="Поиск по названию и алиасам" value="${escapeHtml(q)}" autocomplete="off"></div>
  <div class="filter-row">${['Все', ...GROUPS].map(g => `<button class="f-chip${group === g ? ' active' : ''}" data-action="group" data-g="${g}">${g}</button>`).join('')}</div>
  <div id="cat-list">${listHTML()}</div>
  <button class="btn big" data-action="new-ex">${icon('plus')} Своё упражнение</button>
  <p class="muted tiny" style="margin-top:10px">Алиасы помогают импорту узнавать названия из блокнота — например «Блок бицепс».</p>`;
}

function exModal(e = null) {
  const used = e ? exerciseUsed(e.id) : false;
  openModal({
    html: `
    <div class="modal-title">${e ? 'Упражнение' : 'Новое упражнение'}<span class="spacer"></span><button class="icon-btn plain" data-action="modal-close" aria-label="Закрыть">${icon('x')}</button></div>
    <div class="field-label">Название</div>
    <input id="ex-name" value="${escapeHtml(e?.name ?? '')}" placeholder="Каноническое название">
    <div class="field-label">Мышечная группа</div>
    <select id="ex-group">${GROUPS.map(g => `<option ${e?.group === g ? 'selected' : ''}>${g}</option>`).join('')}</select>
    <div class="field-label">Снаряд</div>
    <select id="ex-eq"><option value="">—</option>${EQUIPMENT.map(g => `<option ${e?.equipment === g ? 'selected' : ''}>${g}</option>`).join('')}</select>
    <div class="field-label"><span>Алиасы из блокнота</span><span class="muted">через запятую</span></div>
    <input id="ex-aliases" value="${escapeHtml((e?.aliases ?? []).join(', '))}" placeholder="блок бицепс, бицепс блок">
    <div style="height:16px"></div>
    <div class="btn-row">
      ${e && !used ? `<button class="btn danger" data-action="del-ex" data-id="${e.id}" style="flex:0 0 auto">${icon('trash')}</button>` : ''}
      <button class="btn primary big" data-action="save-ex" data-id="${e?.id ?? ''}">${icon('check')} Сохранить</button>
    </div>
    ${used ? '<p class="muted tiny" style="margin-top:8px">Упражнение используется в тренировках — удаление недоступно, чтобы не потерять историю.</p>' : ''}`,
    actions: {
      'save-ex': async () => {
        const name = document.getElementById('ex-name').value.trim();
        if (!name) return document.getElementById('ex-name').focus();
        const patch = {
          name, group: document.getElementById('ex-group').value,
          equipment: document.getElementById('ex-eq').value || null,
          aliases: document.getElementById('ex-aliases').value.split(',').map(s => s.trim()).filter(Boolean),
        };
        if (e) await updateExercise(e.id, patch); else await addExercise(patch);
        closeModal();
      },
      'del-ex': async el => { await deleteExercise(el.dataset.id); closeModal(); },
    },
  });
}

export const actions = {
  group: el => { group = el.dataset.g; notify(); },
  'edit-ex': el => exModal(state.exercises.find(e => e.id === el.dataset.id)),
  'new-ex': () => exModal(),
};
export const inputs = {
  q: el => { q = el.value; document.getElementById('cat-list').innerHTML = listHTML(); },
};
