// ПОДХОД · карточка тренировки: чипы / текст блокнота, копирование, удаление (FR-11)
import { state, workoutById, exerciseById, entriesOf, setsOf, deleteWorkout, notify } from '../core/store.js';
import { fmtDateFull, fmtInt, fmtDuration, escapeHtml } from '../core/util.js';
import { SPLITS } from '../core/scheduler.js';
import { workoutStats } from '../core/analytics.js';
import { workoutText } from '../core/format.js';
import { navigate, back } from './router.js';
import { icon, plateNum, splitTag, setChip, empty, copyText } from './components.js';

let view = 'chips';

export function render(id) {
  const w = workoutById(id);
  if (!w) return empty('🤷', 'Тренировка не найдена', 'Возможно, она была удалена');
  if (!w.finishedAt) return `
    ${empty('⏱', 'Эта тренировка ещё идёт')}
    <button class="btn primary big" data-action="nav" data-to="journal">${icon('play')} Открыть журнал</button>`;

  const stats = workoutStats(w.id, state.entries, state.sets);
  const entries = entriesOf(w.id);
  const text = workoutText(w, state.entries, state.exercises, state.sets);

  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="back" aria-label="Назад">${icon('chevL')}</button>
    ${plateNum(w.num, w.split, true)}
    <div style="flex:1;min-width:0">
      <h1 class="display" style="font-size:1.3rem">№${w.num}</h1>
      <div class="head-sub">${splitTag(w.split)} · ${fmtDateFull(w.date)}</div>
    </div>
  </div>

  <div class="tiles">
    <div class="tile"><div class="tile-l">Длительность</div><div class="tile-v" style="font-size:1.15rem">${w.durationMin ? fmtDuration(w.durationMin) : '—'}</div></div>
    <div class="tile"><div class="tile-l">Подходы</div><div class="tile-v" style="font-size:1.15rem">${stats.sets}</div></div>
    <div class="tile"><div class="tile-l">Тоннаж</div><div class="tile-v" style="font-size:1.15rem">${fmtInt(stats.tonnage)} кг</div></div>
    <div class="tile"><div class="tile-l">Рекорды</div><div class="tile-v" style="font-size:1.15rem;color:var(--primary)">★ ${stats.prs}</div></div>
  </div>

  ${w.energy ? `<div class="banner">${icon('zap')}<span class="grow">Самочувствие: <b>${w.energy}/5</b></span></div>` : ''}
  ${w.note ? `<div class="banner">${icon('note')}<span class="grow" style="white-space:pre-wrap">${escapeHtml(w.note)}</span></div>` : ''}

  <div class="seg" style="margin-bottom:12px">
    <button class="${view === 'chips' ? 'active' : ''}" data-action="view" data-v="chips">Чипы</button>
    <button class="${view === 'text' ? 'active' : ''}" data-action="view" data-v="text">Текст блокнота</button>
  </div>

  ${view === 'chips' ? `
  <div class="card">
    ${entries.map(e => {
      const ex = exerciseById(e.exerciseId);
      const gs = setsOf(e.id);
      return `<div class="exercise-block">
        <div class="ex-name">${escapeHtml(ex?.name ?? 'Упражнение')} <span class="group-tag">${ex?.group ?? ''}</span></div>
        <div class="set-row">${gs.map(g => setChip(g, { stat: true })).join('') || '<span class="muted small">без подходов</span>'}</div>
      </div>`;
    }).join('')}
  </div>` : `
  <pre class="notebook-text" id="nb-text">${escapeHtml(text)}</pre>
  <div style="height:10px"></div>`}

  <div class="btn-row">
    <button class="btn" data-action="copy" id="copy-btn">${icon('copy')} Копировать текст</button>
    <button class="btn danger" data-action="delete" style="flex:0 0 auto" aria-label="Удалить тренировку">${icon('trash')}</button>
  </div>
  <p class="muted tiny" style="text-align:center;margin-top:10px">Удаление обратимо в течение 5 секунд</p>
  `;
}

export const actions = {
  back: () => { if (history.length > 1) back(); else navigate('history'); },
  view: el => { view = el.dataset.v; notify(); },
  copy: async el => {
    const w = workoutById(currentId());
    if (!w) return;
    const ok = await copyText(workoutText(w, state.entries, state.exercises, state.sets));
    el.innerHTML = ok ? `${icon('check')} Скопировано` : 'Не вышло — выделите текст вручную';
    setTimeout(() => { const b = document.getElementById('copy-btn'); if (b) b.innerHTML = `${icon('copy')} Копировать текст`; }, 1600);
  },
  delete: async () => {
    const id = currentId();
    await deleteWorkout(id);
    navigate('history');
  },
};

const currentId = () => decodeURIComponent(location.hash.split('/')[2] ?? '');
