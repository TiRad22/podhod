// ПОДХОД · утилиты (чистые функции, работают и в браузере, и в node)

export const uuid = () =>
  (globalThis.crypto?.randomUUID?.() ??
    'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = (Math.random() * 16) | 0;
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    }));

export const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
export const round2 = v => Math.round(v * 100) / 100;
export const round1 = v => Math.round(v * 10) / 10;

// Дата → 'YYYY-MM-DD' в локальной зоне
export const dateISO = (d = new Date()) => {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};
export const todayISO = () => dateISO(new Date());
export const fromISO = iso => {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
};
export const addDaysISO = (iso, n) => {
  const d = fromISO(iso);
  d.setDate(d.getDate() + n);
  return dateISO(d);
};
export const diffDays = (a, b) =>
  Math.round((fromISO(a) - fromISO(b)) / 86400000);

export const WEEKDAYS = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
export const MONTHS = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

// '2026-11-17' → 'вт, 17 ноя'
export const fmtDate = iso => {
  const d = fromISO(iso);
  return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
};
export const fmtDateFull = iso => {
  const d = fromISO(iso);
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
};

// Вес: 4.5 → '4,5', 52 → '52' (запятая, как в блокноте)
export const fmtKg = w => {
  const v = round2(Number(w));
  return String(v).replace('.', ',');
};
// Большое число с тонкими пробелами: 12450 → '12 450'
export const fmtInt = n =>
  Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '\u2009');

export const fmtTon = kg => (kg >= 10000 ? `${fmtInt(kg)} кг` : `${fmtInt(kg)} кг`);

// Минуты → '1 ч 05 мин' / '48 мин'
export const fmtDuration = min => {
  const m = Math.max(0, Math.round(min));
  if (m < 60) return `${m} мин`;
  const h = Math.floor(m / 60);
  return `${h} ч ${String(m % 60).padStart(2, '0')} мин`;
};
// Секунды → '1:30'
export const fmtClock = sec => {
  const s = Math.max(0, Math.ceil(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};
//_MS → 'чч:мм:сс' для живой тренировки
export const fmtElapsed = ms => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`
    : `${m}:${String(s % 60).padStart(2, '0')}`;
};

export const escapeHtml = s =>
  String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Нормализация названия для поиска алиасов: регистр, ё, пробелы
export const normName = s =>
  String(s ?? '').toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();

export const pctDelta = (cur, prev) => {
  if (!prev) return null;
  return Math.round(((cur - prev) / prev) * 100);
};
