// ПОДХОД · расписание сплита и серия (FR-01, FR-16)
import { fromISO, addDaysISO, todayISO } from './util.js';

export const SPLITS = {
  chest: { label: 'Грудь', plate: 25, color: 'var(--chest)', emoji: '🔴' },
  back:  { label: 'Спина', plate: 20, color: 'var(--back)',  emoji: '🔵' },
  legs:  { label: 'Ноги',  plate: 15, color: 'var(--legs)',  emoji: '🟡' },
};
export const SPLIT_KEYS = ['chest', 'back', 'legs'];

// getDay(): 0=вс … 2=вт, 4=чт, 6=сб
export const DEFAULT_SCHEDULE = { 2: 'chest', 4: 'back', 6: 'legs' };

export const splitForDate = (iso, schedule = DEFAULT_SCHEDULE) =>
  schedule?.[fromISO(iso).getDay()] ?? null;

export const nextNum = workouts =>
  workouts.reduce((m, w) => Math.max(m, w.num || 0), 0) + 1;

// Серия: сколько подряд плановых дней (вт/чт/сб) закрыты тренировкой.
// Сегодняшний плановый день без тренировки ещё не считается пропуском.
export function streak(workouts, schedule = DEFAULT_SCHEDULE, today = todayISO()) {
  const done = new Set(workouts.filter(w => w.finishedAt).map(w => w.date));
  let n = 0;
  let iso = today;
  for (let i = 0; i < 400; i++) {
    const planned = splitForDate(iso, schedule);
    if (planned) {
      if (done.has(iso)) n++;
      else if (iso !== today) break;
    }
    iso = addDaysISO(iso, -1);
  }
  return n;
}

// Ближайший плановый день (сегодня, если плановый)
export function nextPlannedDate(schedule = DEFAULT_SCHEDULE, today = todayISO()) {
  for (let i = 0; i < 7; i++) {
    const iso = addDaysISO(today, i);
    const s = splitForDate(iso, schedule);
    if (s) return { date: iso, split: s };
  }
  return null;
}
