// ПОДХОД · история с поиском, фильтрами и сортировкой (FR-10)
import { state, exerciseById, setSetting } from '../core/store.js';
import { fmtDate, fmtInt, normName, escapeHtml } from '../core/util.js';
import { SPLITS } from '../core/scheduler.js';
import { workoutStats } from '../core/analytics.js';
import { icon, plateNum, empty } from './components.js';
import { statLine } from './today.js';

let q = '';
let filter = 'all';

function filtered() {
  const qq = normName(q);
  let ws = state.workouts.filter(w => w.finishedAt);
  if (filter !== 'all') ws = ws.filter(w => w.split === filter);
  if (qq) {
    ws = ws.filter(w => {
      if (String(w.num).includes(qq.replace('№', ''))) return true;
      const eids = state.entries.filter(e => e.workoutId === w.id).map(e => e.exerciseId);
      return eids.some(id => {
        const ex = exerciseById(id);
        return ex && (normName(ex.name).includes(qq) || (ex.aliases ?? []).some(a => normName(a).includes(qq)));
      });
    });
  }
  const dir = state.settings.historySortDesc ? -1 : 1;
  return ws.sort((a, b) => dir * (a.date.localeCompare(b.date) || a.num - b.num));
}

function listHTML() {
  const ws = filtered();
  if (!ws.length) return empty('🔍', q || filter !== 'all' ? 'Ничего не нашлось' : 'История пуста', q ? 'Попробуйте название упражнения или номер' : 'Завершённые тренировки появятся здесь');
  return ws.map(w => `
    <div class="card tap" data-action="open-workout" data-id="${w.id}">
      <div class="card-head">${plateNum(w.num, w.split)}
        <div style="flex:1;min-width:0"><h3>№${w.num} · ${SPLITS[w.split]?.label ?? w.split}</h3><div class="muted small">${fmtDate(w.date)}</div></div>
        ${icon('chevR', 'chev')}
      </div>
      ${statLine(w.id)}
    </div>`).join('');
}

export function render() {
  return `
  <div class="page-head">
    <h1>История</h1><span class="spacer"></span>
    <button class="icon-btn" data-action="toggle-sort" aria-label="Сортировка">${icon(state.settings.historySortDesc ? 'down' : 'up')}</button>
  </div>
  <div class="search-wrap">${icon('search')}<input data-input="q" placeholder="Упражнение или № тренировки" value="${escapeHtml(q)}" autocomplete="off"></div>
  <div class="filter-row">
    ${[['all', 'Все'], ['chest', 'Грудь'], ['back', 'Спина'], ['legs', 'Ноги']].map(([k, l]) =>
      `<button class="f-chip${filter === k ? ' active' : ''}" data-action="filter" data-f="${k}">${l}</button>`).join('')}
    <span style="flex:1"></span>
    <span class="muted tiny" style="align-self:center;white-space:nowrap">${state.settings.historySortDesc ? 'новые → старые' : 'старые → новые'}</span>
  </div>
  <div id="history-list">${listHTML()}</div>`;
}

export const actions = {
  filter: el => { filter = el.dataset.f; document.getElementById('history-list').innerHTML = listHTML(); document.querySelectorAll('.f-chip').forEach(c => c.classList.toggle('active', c.dataset.f === filter)); },
  'toggle-sort': () => setSetting('historySortDesc', !state.settings.historySortDesc),
};
export const inputs = {
  q: el => { q = el.value; document.getElementById('history-list').innerHTML = listHTML(); },
};
