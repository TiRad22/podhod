// ПОДХОД · настройки: темы, отдых, расписание, модули, напоминания, бэкап (FR-21, 23, 24, 25, 28)
import { state, setSetting, setFlag, importJSON, wipeAll, notify } from '../core/store.js';
import { escapeHtml, WEEKDAYS } from '../core/util.js';
import { SPLITS, SPLIT_KEYS } from '../core/scheduler.js';
import { navigate } from './router.js';
import { icon, stepper, toggleRow, openModal, closeModal } from './components.js';
import { getInstallPrompt } from '../app.js';
import { doExport } from './more.js';

const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0];
const DAY_FULL = { 0: 'Воскресенье', 1: 'Понедельник', 2: 'Вторник', 3: 'Среда', 4: 'Четверг', 5: 'Пятница', 6: 'Суббота' };

export function render() {
  const s = state.settings;
  const r = s.reminders;
  const canInstall = !!getInstallPrompt();
  const notifPerm = 'Notification' in window ? Notification.permission : 'unsupported';
  return `
  <div class="page-head">
    <button class="icon-btn plain" data-action="nav" data-to="more" aria-label="Назад">${icon('chevL')}</button>
    <h1>Настройки</h1>
  </div>

  <div class="section-title">Тема</div>
  <div class="card">
    <div class="seg">
      <button class="${s.theme === 'dark' ? 'active' : ''}" data-action="set-theme" data-v="dark">🌙 Железо</button>
      <button class="${s.theme === 'light' ? 'active' : ''}" data-action="set-theme" data-v="light">☀️ Мел</button>
    </div>
    <p class="muted tiny" style="margin-bottom:0">«Железо» — зал и вечер, «Мел» — улица. Выбор запоминается.</p>
  </div>

  <div class="section-title">Отдых</div>
  <div class="card">
    ${stepper({ key: 'restSec', label: 'Таймер отдыха по умолчанию', value: s.restSec, unit: 'сек', step: 15, min: 15, max: 600, changeOnly: true })}
    ${toggleRow('Автозапуск после подхода', 'кольцо прогресса, +15 с и пропуск', s.autoRest, 'toggle-autorest')}
  </div>

  <div class="section-title">Расписание</div>
  <div class="card">
    ${DAY_ORDER.map(d => `
      <div class="toggle-row">
        <div class="grow"><div class="t-label">${DAY_FULL[d]}</div></div>
        <select data-change="sched" data-day="${d}" style="width:130px;min-height:44px" aria-label="${DAY_FULL[d]}">
          <option value="">отдых</option>
          ${SPLIT_KEYS.map(k => `<option value="${k}" ${s.schedule[d] === k ? 'selected' : ''}>${SPLITS[k].label}</option>`).join('')}
        </select>
      </div>`).join('')}
    <p class="muted tiny">Тренировку вне плана всегда можно создать вручную.</p>
  </div>

  <div class="section-title">Модули</div>
  <div class="card">
    ${toggleRow('Сон и восстановление', 'часы + качество, виджет на «Сегодня», график сон↔тоннаж', s.flags.sleep, 'flag', 'data-f="sleep"')}
    ${toggleRow('Вес тела и замеры', 'вес за 15 секунд, график рядом с тоннажом', s.flags.body, 'flag', 'data-f="body"')}
    ${toggleRow('RPE и флаг отказа', 'опциональная сложность подхода в редакторе', s.flags.rpe, 'flag', 'data-f="rpe"')}
  </div>

  <div class="section-title">Напоминания</div>
  <div class="card">
    ${toggleRow('Напоминать о тренировке', 'локально, без сервера', r.enabled, 'rem-toggle')}
    ${r.enabled ? `
    <div class="toggle-row"><div class="grow"><div class="t-label">Время</div></div>
      <input type="time" value="${r.time}" data-change="rem-time" style="width:120px;min-height:44px"></div>
    <div class="toggle-row"><div class="grow"><div class="t-label">Дни</div></div>
      <div style="display:flex;gap:6px">${[2, 4, 6].map(d => `<button class="f-chip${r.days.includes(d) ? ' active' : ''}" data-action="rem-day" data-d="${d}" style="min-height:40px">${WEEKDAYS[d]}</button>`).join('')}</div></div>
    <div class="toggle-row"><div class="grow"><div class="t-label">Тихие часы</div><div class="t-sub">в это время не беспокоим</div></div>
      <input type="time" value="${r.quietFrom}" data-change="rem-quiet" data-k="quietFrom" style="width:104px;min-height:44px" aria-label="Тихие часы с">
      <input type="time" value="${r.quietTo}" data-change="rem-quiet" data-k="quietTo" style="width:104px;min-height:44px" aria-label="Тихие часы до"></div>
    <div class="toggle-row"><div class="grow"><div class="t-label">Разрешение уведомлений</div>
      <div class="t-sub">${notifPerm === 'granted' ? 'выдано ✓' : notifPerm === 'denied' ? 'запрещено в браузере' : 'нужно разрешение'}</div></div>
      ${notifPerm === 'default' ? `<button class="btn small-btn" data-action="rem-perm">Разрешить</button>` : ''}</div>
    <p class="muted tiny">Без сервера push невозможен: напоминание приходит, пока приложение открыто или свёрнуто недавно. Надёжный будильник — системный.</p>` : ''}
  </div>

  <div class="section-title">Данные</div>
  <div class="card">
    <div class="btn-row" style="margin-bottom:10px">
      <button class="btn" data-action="export">${icon('download')} Экспорт JSON</button>
      <button class="btn" data-action="import-click">${icon('upload')} Импорт JSON</button>
    </div>
    <input type="file" id="import-file" accept=".json,application/json" data-change="import-file" hidden>
    <div class="btn-row">
      <button class="btn" data-action="nav" data-to="import">${icon('note')} Импорт из заметок</button>
    </div>
    <div class="divider"></div>
    <button class="btn danger big" data-action="wipe">${icon('trash')} Сбросить все данные</button>
    <p class="muted tiny" style="margin-bottom:0">Экспорт — полная копия 1-в-1: тренировки, каталог, настройки, сон и тело. Файл версионирован и читаем.</p>
  </div>

  <div class="section-title">Установка на телефон</div>
  <div class="card">
    ${canInstall ? `<button class="btn primary big" data-action="install-app">${icon('download')} Установить ПОДХОД</button>` : `
    <p class="small" style="margin-top:0"><b>Android / Chrome:</b> меню ⋮ → «Установить приложение» / «Добавить на главный экран».</p>
    <p class="small"><b>iPhone / Safari:</b> «Поделиться» → «На экран Домой».</p>
    <p class="muted tiny" style="margin-bottom:0">После установки — иконка-блин, полный экран без браузерной строки и работа в авиарежиме.</p>`}
  </div>

  <p class="muted tiny" style="text-align:center">ПОДХОД v1.0 · офлайн-first · данные только на устройстве<br>5 лет тренировок помещаются в &lt; 5 МБ</p>
  `;
}

async function handleImportFile(file) {
  try {
    const obj = JSON.parse(await file.text());
    if (obj?.app !== 'podhod') throw new Error('Это не бэкап ПОДХОД');
    const n = obj.data?.workouts?.length ?? 0;
    openModal({
      sheet: false,
      html: `
      <div class="modal-title">Импорт бэкапа</div>
      <div class="modal-sub">В файле: ${n} тренировок, ${obj.data?.exercises?.length ?? 0} упражнений, от ${escapeHtml((obj.exportedAt ?? '').slice(0, 10))}.<br><b>Все текущие данные будут заменены.</b></div>
      <div class="btn-row">
        <button class="btn" data-action="modal-close">Отмена</button>
        <button class="btn danger solid" data-action="confirm-import">Заменить</button>
      </div>`,
      actions: {
        'confirm-import': async () => {
          try { await importJSON(obj); closeModal(); navigate('today'); }
          catch (err) { alert('Не вышло: ' + err.message); }
        },
      },
    });
  } catch (err) { alert('Не вышло: ' + err.message); }
}

export const actions = {
  'set-theme': el => setSetting('theme', el.dataset.v),
  step: el => {
    if (el.dataset.key !== 'restSec') return;
    const v = Math.min(600, Math.max(15, (state.settings.restSec || 90) + parseFloat(el.dataset.delta)));
    setSetting('restSec', v);
  },
  'toggle-autorest': () => setSetting('autoRest', !state.settings.autoRest),
  sched: el => {
    const d = el.dataset.day;
    const sc = { ...state.settings.schedule };
    if (el.value) sc[d] = el.value; else delete sc[d];
    setSetting('schedule', sc);
  },
  flag: el => setFlag(el.dataset.f, !state.settings.flags[el.dataset.f]),
  'rem-toggle': () => setSetting('reminders', { ...state.settings.reminders, enabled: !state.settings.reminders.enabled }),
  'rem-time': el => setSetting('reminders', { ...state.settings.reminders, time: el.value || '18:00' }),
  'rem-day': el => {
    const d = +el.dataset.d;
    const days = state.settings.reminders.days.includes(d)
      ? state.settings.reminders.days.filter(x => x !== d)
      : [...state.settings.reminders.days, d];
    setSetting('reminders', { ...state.settings.reminders, days });
  },
  'rem-quiet': el => setSetting('reminders', { ...state.settings.reminders, [el.dataset.k]: el.value }),
  'rem-perm': async () => { await Notification.requestPermission(); notify(); },
  export: doExport,
  'import-click': () => document.getElementById('import-file').click(),
  'import-file': el => { if (el.files?.[0]) handleImportFile(el.files[0]); el.value = ''; },
  stepval: el => {
    if (el.dataset.key !== 'restSec') return;
    const v = parseInt(el.value.replace(',', '.'), 10);
    if (Number.isFinite(v)) setSetting('restSec', Math.min(600, Math.max(15, v)));
  },
  wipe: () => openModal({
    sheet: false,
    html: `
    <div class="modal-title">Сбросить всё?</div>
    <div class="modal-sub">Тренировки, каталог, сон, тело и настройки будут удалены безвозвратно. Сначала сделайте экспорт.</div>
    <div class="btn-row">
      <button class="btn" data-action="modal-close">Отмена</button>
      <button class="btn danger solid" data-action="wipe-confirm">Сбросить</button>
    </div>`,
    actions: { 'wipe-confirm': async () => { await wipeAll(); closeModal(); navigate('today'); } },
  }),
};

export const inputs = {};
